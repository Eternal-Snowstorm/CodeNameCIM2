<img width="165" height="20" alt="logo" src="https://github.com/user-attachments/assets/e3b6b662-ca36-4076-ac68-0b76534ae1a6" />

本资源包将AE2的UI风格移植到了其他模组上

https://www.curseforge.com/minecraft/texture-packs/oreui-for-everyone/

欢迎您制作其他模组的兼容，您可以把你的名字及贡献写到 `contributor.csv` 中

关于适用于Windows10/11的OreUI For Windows ，请见https://github.com/ReConstruction-127/OreUI-For-Windows
