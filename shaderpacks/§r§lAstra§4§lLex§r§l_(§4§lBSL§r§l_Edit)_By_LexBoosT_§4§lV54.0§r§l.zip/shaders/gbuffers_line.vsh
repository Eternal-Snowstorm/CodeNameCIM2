#version 330 compatibility

#define OVERWORLD
#define VSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
