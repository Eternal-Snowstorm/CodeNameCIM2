#version 330 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define GBUFFERS_WATER
#define OVERWORLD
#define FSH

#include "/program/gbuffers_water.glsl"
