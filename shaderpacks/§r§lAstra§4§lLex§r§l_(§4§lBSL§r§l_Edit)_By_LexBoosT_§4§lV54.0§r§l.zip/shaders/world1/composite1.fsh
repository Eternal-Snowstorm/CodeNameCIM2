#version 460 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define END
#define FSH

#include "/program/composite1.glsl"
