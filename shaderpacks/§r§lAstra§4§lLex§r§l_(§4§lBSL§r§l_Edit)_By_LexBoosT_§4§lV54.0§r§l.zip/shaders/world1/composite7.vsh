#version 330 compatibility

#define END
#define VSH

#include "/program/composite7.glsl"
