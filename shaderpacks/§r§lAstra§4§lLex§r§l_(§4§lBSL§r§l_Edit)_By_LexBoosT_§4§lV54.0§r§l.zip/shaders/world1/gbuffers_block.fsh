#version 330 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define END
#define FSH

#include "/program/gbuffers_block.glsl"
