#version 330 compatibility

#define END
#define VSH

#include "/program/deferred.glsl"
