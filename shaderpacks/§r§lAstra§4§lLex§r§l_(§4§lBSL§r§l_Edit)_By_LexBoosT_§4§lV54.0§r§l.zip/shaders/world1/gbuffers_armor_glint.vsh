#version 330 compatibility

#define END
#define VSH

#include "/program/gbuffers_armor_glint.glsl"
