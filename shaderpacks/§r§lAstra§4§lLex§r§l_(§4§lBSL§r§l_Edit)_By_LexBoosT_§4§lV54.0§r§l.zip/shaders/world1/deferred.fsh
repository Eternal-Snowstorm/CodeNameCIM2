#version 460 compatibility

#define END
#define FSH

#include "/program/deferred.glsl"
