#version 330 compatibility

#define END
#define FSH

#include "/program/deferred.glsl"
