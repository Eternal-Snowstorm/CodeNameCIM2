#version 330 compatibility

#define END
#define FSH

#include "/program/composite4.glsl"
