#version 460 compatibility

#define END
#define FSH

#include "/program/composite4.glsl"
