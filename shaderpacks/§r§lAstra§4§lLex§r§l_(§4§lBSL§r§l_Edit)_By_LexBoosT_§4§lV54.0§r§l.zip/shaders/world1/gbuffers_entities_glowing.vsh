#version 330 compatibility

#define GBUFFERS_ENTITIES_GLOWING
#define END
#define VSH

#include "/program/gbuffers_entities.glsl"
