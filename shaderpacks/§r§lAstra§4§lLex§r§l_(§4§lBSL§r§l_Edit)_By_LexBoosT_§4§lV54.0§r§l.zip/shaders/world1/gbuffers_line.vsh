#version 330 compatibility

#define END
#define VSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
