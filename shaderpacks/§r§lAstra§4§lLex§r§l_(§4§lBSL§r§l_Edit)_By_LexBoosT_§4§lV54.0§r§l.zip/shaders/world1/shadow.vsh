#version 330 compatibility

#define END
#define VSH

#include "/program/shadow.glsl"
