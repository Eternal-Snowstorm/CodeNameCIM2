#version 330 compatibility

#define END
#define FSH

#include "/program/composite8.glsl"
