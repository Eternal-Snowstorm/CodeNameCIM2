#version 460 compatibility

#define END
#define FSH

#include "/program/composite8.glsl"
