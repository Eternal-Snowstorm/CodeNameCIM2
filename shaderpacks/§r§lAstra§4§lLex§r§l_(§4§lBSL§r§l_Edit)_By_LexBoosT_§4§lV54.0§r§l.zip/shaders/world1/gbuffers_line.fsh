#version 460 compatibility

#define END
#define FSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
