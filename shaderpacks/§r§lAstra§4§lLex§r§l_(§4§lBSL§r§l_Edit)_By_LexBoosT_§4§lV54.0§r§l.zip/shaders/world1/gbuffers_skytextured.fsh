#version 460 compatibility

#define END
#define FSH

#include "/program/gbuffers_skytextured.glsl"
