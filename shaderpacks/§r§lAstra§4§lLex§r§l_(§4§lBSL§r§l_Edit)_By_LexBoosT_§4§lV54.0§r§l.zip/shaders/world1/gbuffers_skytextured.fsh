#version 330 compatibility

#define END
#define FSH

#include "/program/gbuffers_skytextured.glsl"
