#version 330 compatibility

#define OVERWORLD
#define VSH

#include "/program/gbuffers_textured.glsl"
