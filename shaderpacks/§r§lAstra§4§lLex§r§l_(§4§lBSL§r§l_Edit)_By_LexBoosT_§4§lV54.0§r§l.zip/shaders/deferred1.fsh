#version 460 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define DEFERRED
#define OVERWORLD
#define FSH

#include "/program/deferred1.glsl"
