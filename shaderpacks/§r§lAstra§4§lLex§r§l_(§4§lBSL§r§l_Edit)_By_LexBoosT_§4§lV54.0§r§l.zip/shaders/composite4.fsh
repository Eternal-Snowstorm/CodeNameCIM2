#version 460 compatibility

#define OVERWORLD
#define FSH

#include "/program/composite4.glsl"
