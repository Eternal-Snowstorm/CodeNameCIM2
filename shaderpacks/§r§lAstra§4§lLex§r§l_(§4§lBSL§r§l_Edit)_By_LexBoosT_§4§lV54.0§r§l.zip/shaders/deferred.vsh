#version 330 compatibility

#define OVERWORLD
#define VSH

#include "/program/deferred.glsl"
