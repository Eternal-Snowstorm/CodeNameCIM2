#version 460 compatibility

#define OVERWORLD
#define FSH

#include "/program/composite10.glsl"
