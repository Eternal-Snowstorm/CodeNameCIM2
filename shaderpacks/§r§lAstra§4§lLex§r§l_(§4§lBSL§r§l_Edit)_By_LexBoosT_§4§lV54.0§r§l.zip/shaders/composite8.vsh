#version 330 compatibility

#define OVERWORLD
#define VSH

#include "/program/composite8.glsl"
