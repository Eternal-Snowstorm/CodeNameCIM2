/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//
#include "/settings/about.glsl"
#include "/lib/util/fastMath.glsl"
#include "/settings/globalSettings.glsl"
#include "/settings/finalSettings.glsl"
#include "/settings/optifineMenu.glsl"

//Varyings//
varying vec2 texCoord;

varying vec3 upVec, sunVec;

varying vec4 color;

#ifdef DISTORTION
	varying vec3 vUV;
	varying vec2 vUVDot;
#endif

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform sampler2D noisetex;
	uniform sampler2D colortex1;

	#ifdef HYPER_SPEED
		uniform float effectStrength;
		uniform sampler2D depthtex1;
	#endif

	uniform float aspectRatio;
	uniform float frameTimeCounter;
	uniform float viewWidth, viewHeight;
	uniform float blindness;
	uniform float screenBrightness;

	#ifdef ENABLE_DARKNESS_EFFECT
		#if MC_VERSION >= 11900
			uniform float darknessFactor;
			uniform float darknessLightFactor;
		#endif
	#endif

	uniform int frameCounter;

	#if defined HIT_RED_VIGNETTE || defined ELECTROCARDIOGRAM
		uniform float touchmybody;
	#endif

	#if defined CONCENTRATION || defined BANDES && defined CONCENTRATION
		uniform float sneakSmooth;
	#endif

	#ifdef BURNING_EFFECT
		uniform float burningSmooth;
	#endif

	uniform float rainStrength;
	uniform float rainStrengthS;
	uniform float rainStrengthS2;

	uniform float biomeHasRainSmooth;
	uniform float biomeisNotColdSmooth;

	#if defined (OVERWORLD) && defined DESERT_REFRACT
		uniform float biomeHasHeatSmooth;
	#endif

	#if defined (OVERWORLD) && defined MESA_REFRACT
		uniform float biomeHasHeatSmooth2;
	#endif

	#if defined (NETHER) && defined NETHER_REFRACT
		uniform float biomeHasHeatSmooth3;
	#endif

	#if defined (OVERWORLD) && defined ARC_EN_CIEL

		uniform mat4 gbufferProjectionInverse;
		uniform sampler2D depthtex0;
		uniform float wetness;
		uniform vec3 sunPosition;
		uniform vec3 cameraPosition;
		vec3 sunPosNorm=normalize(sunPosition);

		#ifdef FIXED_RAINBOW
			uniform mat4 gbufferModelView, gbufferModelViewInverse;
		#endif

	#endif

	#ifdef BARREL
		uniform mat4 gbufferProjection;
	#endif

	#if defined VISEUR || defined MODE_RAGE
		uniform int heldItemId;
	#endif

	#ifdef COLOR_START
		uniform float starter;
	#endif

	uniform ivec2 eyeBrightnessSmooth;

	uniform int isEyeInWater;

	//Optifine Constants//
	/*
	const int colortex0Format=R11F_G11F_B10F;  //main scene
	const int colortex1Format=RGBA16;          //raw translucent, bloom, final scene
	const int colortex2Format=RGBA16;          //temporal data
	const int colortex3Format=RGB8;            //specular data
	const int colortex4Format=RGBA8;   	   	   //ao
	const int gaux1Format    =R8;              //cloud alpha, ao
	const int gaux2Format    =RGB10_A2;        //reflection image
	const int gaux3Format    =RGB16;           //normals
	const int gaux4Format    =RGB16;           //fresnel
	*/

	const bool colortex0Clear  = true;
	const bool colortex1Clear  = true;
	const bool colortex2Clear  = false;
	const bool colortex3Clear  = true;
	const bool colortex5Clear  = false;
	const bool colortex9Clear  = true;
	const bool colortex10Clear = true;
	const bool colortex11Clear = true;
	const bool gaux1Clear      = false;
	const bool gaux2Clear      = false;
	const bool gaux3Clear      = false;
	const bool gaux4Clear      = true;


	const float ambientOcclusionLevel  =0.5;    //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
	const float centerDepthHalflife    =2.0;    //[0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8 3.0 3.2 3.4 3.6 3.8 4.0]
	const bool shadowHardwareFiltering =true;
	const float shadowDistanceRenderMul=1.0;
	const float entityShadowDistanceMul=0.125;
	const int noiseTextureResolution   =512;
	const float wetnessHalflife        =500.0; //[100.0 200.0 300.0 400.0 500.0 600.0 700.0 800.0 900.0 1000.0]
	const float drynessHalflife        =50.0;   //[50.0 100.0 125.0 150.0 175.0 200.0 225.0 250.0 275.0 300.0]

	//Common Functions//

	float eBS          =eyeBrightnessSmooth.y / 240.0;
	float eBS2         =clamp01((eyeBrightnessSmooth.y-220)/15.0);
	float sunVisibility=clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2=clamp01(screenBrightness);

	#ifdef BARREL
		vec2 distortBarrel(vec2 coord, float strength) {
		coord -= vec2(0.5);
		coord *= 1.0 - strength * dot(coord, coord);
		return coord + vec2(0.5);
		}
	#endif

	#if defined BRUIT_CAMERA || defined COLOR_START
		float GetLuminance(vec3 color){
			return dot(color,vec3(0.299, 0.587, 0.114));
		}
	#endif

	//Includes//

	#include "/lib/util/dither.glsl"

	#if defined (OVERWORLD) && defined ARC_EN_CIEL
	#include "/lib/color/dimensionColor.glsl"
	#endif

	#ifdef ELECTROCARDIOGRAM
	#include "/lib/color/electrocardiogramColor.glsl"
	#endif

	#if defined DITHERING_SCREEN || defined DITHERING_SCREEN_2
	#include "/lib/util/lexClosest.glsl"
	#endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////////SHARPEN_AA/////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#ifdef SHARPEN_AA
        #if AA > 1
            vec2 sharpenOffsets[4] = vec2[4](
                vec2( 1.0,  0.0),
                vec2( 0.0,  1.0),
                vec2(-1.0,  0.0),
                vec2( 0.0, -1.0)
            );

            void SharpenFilter(inout vec3 color, vec2 texCoord){
                float mult=MC_RENDER_QUALITY * 0.0625;
                vec2  view=1.0 / vec2(viewWidth, viewHeight);

                color*=MC_RENDER_QUALITY * 0.25 + 1.0;

                for(int i = 0; i < 4; i++) {
                    vec2 offset =sharpenOffsets[i] * view;
                         color -=texture2DLod(colortex1, texCoord + offset, 0.0).rgb * mult;
                }
            }
        #endif
    #endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////////FILM GRAIN/////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#include "/lib/post/filmgrain.glsl"

	/*///////////////////////////////////////////////////////////////////////////
	////////////////////////////UNDERWATER_REFRACT//////////////////////////////
	/////////////////////////////////////////////////////////////////////////*/

	vec2 underwaterRefraction(vec2 coord){

		if (isEyeInWater>0 && isEyeInWater <3){

				#ifdef MOUVEMENT_EAU
					const float refractionMultiplier=RMULTIPLIER;
					const float refractionSpeed     =RSPEED;
					const float refractionSize      =1.5;

					vec2 refractCoord=vec2(sin(frameTimeCounter * RSPEED + coord.x * 25.0 * refractionSize + coord.y * 12.5 * refractionSize), 0.0);

					return bool(float(isEyeInWater)> 0.9) ? coord + refractCoord * RMULTIPLIER : coord;
				#endif
		}

			return coord;
	}

	/*///////////////////////////////////////////////////////////////////////////
	//////////////////////////////RAIN_DROPS////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////*/

	#include "/lib/atmospherics/raindrop.glsl"

	/*///////////////////////////////////////////////////////////////////////////
	//////////////////////////////BIOMES & BURNING REFACT///////////////////////
	/////////////////////////////////////////////////////////////////////////*/

	#include "/lib/others/refract.glsl"

	/*///////////////////////////////////////////////////////////////////////////
	//////////////////////////////BLINDNESS_EFFECT//////////////////////////////
	/////////////////////////////////////////////////////////////////////////*/

	vec3 blindnessEffect(vec3 clr){

		const float blindnessAmount=0.9;

		float dist=min(pow(distance(texCoord.st, vec2(0.5)),1.4)*1.4,1.0);

		return mix(clr,vec3(0.0), blindness * dist);

	}

	/*///////////////////////////////////////////////////////////////////////
	///////////////////////////////////SCANLINE_BAND////////////////////////
	/////////////////////////////////////////////////////////////////////*/

	#ifdef SCANLINE_BAND

		const float PI = 3.1415927;

		float sinEsp(float a,float esp){

			float cycle=mod(a/(2.0*PI),esp);
			if(cycle<=0.5)
			{
				return sin(a);
			}
			else
			{
				return 0.0;
			}

		}
	#endif

	/*///////////////////////////////////////////////////////////////////////
	////////////////////////////////////Tube Border/////////////////////////
	/////////////////////////////////////////////////////////////////////*/

	#ifdef CRT_BORDER

		#if CRT_BORDER_STRENGTH==1
			float crtBorder=75.0;
		#elif CRT_BORDER_STRENGTH==2
			float crtBorder=55.0;
		#elif CRT_BORDER_STRENGTH==3
			float crtBorder=35.0;
		#elif CRT_BORDER_STRENGTH==4
			float crtBorder=25.0;
		#endif

		float tubeBorder(){
			vec2 a=texCoord.st*(1.-texCoord.st)*(crtBorder+texCoord.st);
			return mix(2.0-pow(a.x*a.y,0.25),1.0,0.9);
		}

		vec2 calculateDistortion(){
			vec2 coord=texCoord.st*2.0 - 1.0;
			coord*=tubeBorder();

			return coord*0.5+0.5;
		}

		void calculateBorder(inout vec3 color){
			color*=smoothstep(1.0,0.95,tubeBorder());
		}
	#endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////////BRUIT_CAMERA///////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	vec3 doBruitCam(vec3 clr){

		const float noiseStrength=FORCE_BRUIT;
		const float noiseResoltion=7.5;

		#ifdef BRUIT_CAMERA

			vec2 aspectcorrect=vec2(aspectRatio, 1.0);

			vec3 rgbNoise=texture2D(noisetex, texCoord.st * noiseResoltion * aspectcorrect + vec2(frameTimeCounter *15.0, frameTimeCounter * 5.0)).rgb;

			clr=mix(clr, rgbNoise, GetLuminance(rgbNoise) * noiseStrength);

		#endif

		return clr;

	}

	/*////////////////////////////////////////////////////////////////////////
	/////////////////////////////////VISEUR//////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#ifdef VISEUR

	void aim(inout vec4 color){

		if(abs(texCoord.s - 0.4875)< 0.0005 && abs(texCoord.t - 0.45)< 0.1)    color=vec4(1)-color;
		if(abs(texCoord.s - 0.5125)< 0.0005 && abs(texCoord.t - 0.45)< 0.1)    color=vec4(1)-color;
		if(abs(texCoord.t - 0.45)  < 0.0008 && abs(texCoord.s - 0.5) < 0.0075) color=vec4(1)-color;
		if(abs(texCoord.t - 0.4)   < 0.0008 && abs(texCoord.s - 0.5) < 0.005)  color=vec4(1)-color;
		if(abs(texCoord.t - 0.35)  < 0.0008 && abs(texCoord.s - 0.5) < 0.0025) color=vec4(1)-color;
		if(abs(texCoord.t - 0.3)   < 0.0008 && abs(texCoord.s - 0.5) < 0.001)  color=vec4(1)-color;
	}
	#endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////////MODE_RAGE//////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#ifdef MODE_RAGE
	void killingVignette(inout vec4 color){

		#ifdef HEARTBEAT
			float heartBeat=sin(frameTimeCounter * 1.0 * HEARTBEAT_SPEED) + 1.0 + cos(frameTimeCounter * 2.0 * HEARTBEAT_SPEED) + 1.0;
		#else
			float heartBeat=1.0;
		#endif

		vec4 vignetteColor = vec4(0.8118, 0.0706, 0.0706,1.0) * pow(distance(texCoord.st, vec2(0.5)), 2.0) * heartBeat;
		color = mix(color, vignetteColor, clamp01(length(vignetteColor.rgb)));
	}
	#endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////ULTRA_VIGNETTE/////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#ifdef ULTRA_VIGNETTE
		void ultraVignette(inout vec4 vignColor)
		{
			vec2 uv = texCoord.st;

			vec2 curve = pow(abs(uv * 2.0 - 1.0),vec2(1.0 / VIGNETTE_CURVATURE));

			float edge = pow(length(curve), VIGNETTE_CURVATURE);

			float vignette = 1.0 - VIGNETTE_STRENGTH * smoothstep(VIGNETTE_INNER, VIGNETTE_OUTER, edge);

			vignColor *= vignette;
		}
	#endif

	#ifdef ENABLE_DARKNESS_EFFECT
		#if MC_VERSION >= 11900

			#if SCREEN_DIMMING == 1
					float screenDimming = 1.0;
				#endif

				#if SCREEN_DIMMING == 2
					float screenDimming = 1.5;
				#endif

				#if SCREEN_DIMMING == 3
					float screenDimming = 2.0;
				#endif

			void ColorDarknessBeat(inout vec4 ColorDarkness)
			{
				ColorDarkness *= (1.0 - darknessLightFactor * screenDimming);
			}
		#endif
	#endif

	/*////////////////////////////////////////////////////////////////////////
	//////////////////////////////////DAMAGE/////////////////////////////////
	//////////////////////////////////////////////////////////////////////*/

	#ifdef HIT_RED_VIGNETTE
		vec3 damage_visual(vec3 color){

			return color + (vec3(1.0, 0.0, 0.0) *pow(distance(texCoord.st, vec2(0.5)), 2.0) * touchmybody);

		}
	#endif

	#ifdef ELECTROCARDIOGRAM

		vec3 heartBeatLine(inout vec3 electroColor){

			float time = frameTimeCounter;
			float persist = 2.5;
			float speed = 2.0;
			float persistence = 90.0;

			float thickness = ECG_THICKNESS;

			vec2 uV = (texCoord-vec2(0.5))*vec2(aspectRatio,1.0);

			vec3 heartBeat = vec3(1.0 - smoothstep( 0.0,thickness, distance(uV, vec2(uV.x, ((sin((uV.x/2.0) * persistence) / ((uV.x / 2.0) * 5.0 * persistence)) +
							sin(uV.x * persistence) / 5.0) * clamp01((1.0 - abs((uV.x / 2.0) * 12.0))))))
							);

			vec3 light = vec3(1.0 - smoothstep(0.0, (thickness + 0.02), distance(0.0, clamp01((uV.x + persist - fract(time * speed) * (1.0 + persist)) / persist) )) *
							(1.0 - step(1.0, distance(0.0, (uV.x + persist - fract(time * speed) * (1.0 + persist)) / persist * 2.5)))
							);

			vec3 color = electroCol.rgb;

			return electroColor += vec3((heartBeat * light) * color) * touchmybody;
		}

	#endif

	/*/////////////////////////////////////////////////////////////////////
	/////////////////////////////////MAIN/////////////////////////////////
	///////////////////////////////////////////////////////////////////*/


	//Program//
	void main(){

		vec2 newtex=texCoord.st;

		#if defined DITHERING_SCREEN_2 || defined DOWNSCALE
		vec2  baseRes     =vec2(viewWidth, viewHeight);
		vec2  scaleBaseRes=baseRes * RESOLUTION_SCALE;
		float pixelSize   =scaleBaseRes.x / baseRes.x;
		#endif

		#if defined DISTORTION
			vec3 distort=dot(vUVDot, vUVDot)*vec3(-0.5, -0.5, -1.0)+vUV;
			     newtex =distort.xy/distort.z;
		#endif

		vec2 newtexcoord=raindropRefraction(underwaterRefraction(newtex));
		     newtexcoord=biomeRefraction(newtexcoord);

		#if defined DITHERING_SCREEN_2 || defined DOWNSCALE
			vec2 downscale=floor(newtexcoord * (scaleBaseRes - 1) + 0.5) / (scaleBaseRes - 1);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////MAIN_HYPER_SPEED///////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef HYPER_SPEED

			float z   =texture2D(depthtex1,newtex.st).x;
			float hand=float(z<0.56);

			vec4  color =vec4(0.0);
			float dither=texture2DLod(colortex1, newtex.xy * 0.0625, 0.0).r;

			if(hand<.5){

				for(int i=0;i<16;i++){
					float f         =float(i)+dither;
					float weight    =1.0 - abs(f * 0.125 - 1.0);
					vec3  sample    =texture2DLod(colortex1, mix(newtexcoord,vec2(0.5), f * 0.03125 * effectStrength * HYPERSPEED_MULTIPLIER), 0.0).rgb;
					      color.rgb+=sample * sample * weight;
					      color.a  +=weight;
				}

				color.rgb*=(effectStrength * 1.0 + 1.0);
				color.rgb/=8.0;
				color.rgb =sqrt(color.rgb);
			}else{
				color=texture2DLod(colortex1, newtexcoord, 0.0).rgba;
			}
		#else

			#ifdef DOWNSCALE
			vec4 color=texture2DLod(colortex1, downscale, 0.0).rgba;
			#else
			vec4 color=texture2DLod(colortex1, newtexcoord, 0.0).rgba;
			#endif

		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_RAGE/////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef MODE_RAGE
			if(heldItemId==10267||heldItemId==10268||heldItemId==10276||heldItemId==10278||heldItemId==10283)killingVignette(color.rgba);
		#endif

		/*/////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////MAIN_ULTRA_VIGNETTE//////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef ULTRA_VIGNETTE
			ultraVignette(color.rgba);
		#endif

		#ifdef ENABLE_DARKNESS_EFFECT
			#if MC_VERSION >= 11900
				ColorDarknessBeat(color.rgba);
			#endif
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////BLINDNESS_EFFECT////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		color.rgb = blindnessEffect(color.rgb);

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////////MAIN_DITHERING///////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef DITHERING_SCREEN
			float dither2=lexClosest(newtex.xy);
			color.rgb=pow(color.rgb,vec3(1.0 / 2.2));

			color.r=floor(color.r * DITHERING_SAMPLES + dither2) / DITHERING_SAMPLES;
			color.g=floor(color.g * DITHERING_SAMPLES + dither2) / DITHERING_SAMPLES;
			color.b=floor(color.b * DITHERING_SAMPLES + dither2) / DITHERING_SAMPLES;

			color.rgb=pow(color.rgb,vec3(2.2));
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////MAIN_DITHERING_SCREEN_2//////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef DITHERING_SCREEN_2
			color.rgb = lexClosest2(vec2(downscale.x, downscale.y / aspectRatio) * scaleBaseRes.x, color.rgb, DITHERING_SAMPLES_2);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_POSTERIZATION////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef POSTERIZATION
			color.rgb=pow(color.rgb,vec3(1.0 / 2.2));

			if(length(color.rgb)<0.5)color.rgb=floor(normalize(color.rgb) * POSTERIZATION_LIMIT * 2.0) / POSTERIZATION_LIMIT / 2.0 * floor(length(color.rgb * POSTERIZATION_LIMIT)) / POSTERIZATION_LIMIT;
			if(length(color.rgb)>0.5)color.rgb=ceil(normalize(color.rgb) * POSTERIZATION_LIMIT *2.0) / POSTERIZATION_LIMIT / 2.0 * ceil(length(color.rgb * POSTERIZATION_LIMIT)) / POSTERIZATION_LIMIT;
			color.rgb=pow(color.rgb,vec3(2.2));

		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_ARC_EN_CIEL//////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#if defined (OVERWORLD) && defined ARC_EN_CIEL

			vec4 fragposition =gbufferProjectionInverse * (vec4(newtex.st, texture2D(depthtex0,newtex.st).x, 1.0) * 2.0 - 1.0);
			     fragposition/=fragposition.w;

			#ifndef FIXED_RAINBOW
				float sunDot=dot(sunPosNorm,normalize(fragposition.xyz)) * 0.5 + 0.5;
			#else
				vec3  newSunPosNorm   =(gbufferModelViewInverse * vec4(sunPosNorm,0.0)).xyz;
				      newSunPosNorm   =vec3(newSunPosNorm.x * 100.0, newSunPosNorm.y / 100.0, newSunPosNorm.z * 100.0);
				      newSunPosNorm.y+=FIXED_RAINBOW_POS;
				      newSunPosNorm   =(gbufferModelView * vec4(newSunPosNorm,0.0)).xyz;
				float sunDot          =dot(normalize(newSunPosNorm.xyz), normalize(fragposition.xyz)) * 0.50 + 0.50;
			#endif

			if(length(fragposition.xyz) > DISTANCE_ARC_EN_CIEL && isEyeInWater == 0 && (worldTime > 1000.0 && worldTime < 12000.0))
			{
				float rainbowStrength=(wetness - rainStrengthS) * 0.015 * RAINBOW_INTENSITY;
				float rainbowHue     =(sunDot - 0.05 * DIAMETRE_ARC_EN_CIEL) * -50.0 / EPAISSEUR_ARC_EN_CIEL;
				if(rainbowStrength > 0.01 && rainbowHue > 0.0 && rainbowHue < 1.0){
					rainbowHue*=6.0;
					vec3 rainbowColor = vec3(0.0);
					rainbowColor.r   =clamp01(1.5-abs(rainbowHue - 1.5)) * rainbowStrength;
					rainbowColor.g   =clamp01(2.0-abs(rainbowHue - 3.0)) * rainbowStrength;
					rainbowColor.b   =clamp01(1.5-abs(rainbowHue - 4.5)) * rainbowStrength;

					#ifdef UNDERGROUND_SKY
						if (isEyeInWater<1){
							float ug = mix(clamp01((cameraPosition.y - 48.0) / 16.0), 1.0, eBS);
							rainbowColor.rgb = mix(minLightCol.rgb * 0.125, rainbowColor.rgb, ug);
						}
					#endif

					#if MC_VERSION >=11800
						rainbowColor.rgb*=clamp01((cameraPosition.y + 70.0) / 8.0);
					#else
						rainbowColor.rgb*=clamp01((cameraPosition.y + 6.0) / 8.0);
					#endif

					#ifdef ENABLE_DARKNESS_EFFECT
						#if MC_VERSION >= 11900
							rainbowColor.rgb *= 1.0 - darknessFactor;
						#endif
					#endif

					color.rgb += rainbowColor.rgb;

				}
			}

		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////MAIN_DAMAGE/////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef HIT_RED_VIGNETTE
			color.rgb = damage_visual(color.rgb);
		#endif

		#ifdef ELECTROCARDIOGRAM
			heartBeatLine(color.rgb);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_SCANLINE/////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#if defined SCANLINE || defined SCANLINE_BAND
			float scanline        =0.0;
			float frameTimeCounter=frameTimeCounter * 1.0;
		#endif

		#if CRT ==0
		#endif

		#if CRT ==1
		float scanlineY=0.0;
		float scanlineX=0.0;

			scanlineY =sin(newtex.y * viewHeight * 2.0 / EPAISSEUR_CRT);
			scanlineX =sin(newtex.x * viewWidth * 2.0 /EPAISSEUR_CRT);
			color.rgb*=1.0 + scanlineY * FORCE_CRT * 0.1 + scanlineX * FORCE_CRT * 0.1;
		#endif

		#ifdef SCANLINE
			scanline  =sin(newtex.y * viewHeight * 2.0 / EPAISSEUR_SCANLINE + frameTimeCounter * VITESSE_SCANLINE);
			color.rgb*=1.0 + scanline * FORCE_SCANLINE * 0.1;
		#endif

		#ifdef SCANLINE_BAND
			scanline  =sinEsp(newtex.y * viewHeight * 2.0 / EPAISSEUR_BAND + frameTimeCounter * VITESSE_BAND,INTERVAL_BAND);
			color.rgb/=1.0 + scanline * FORCE_BAND * 0.5;
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////MAIN_CRT_BORDER////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef CRT_BORDER
			calculateBorder(color.rgb);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_BRUIT_CAM////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef BRUIT_CAMERA
			color.rgb=doBruitCam(color.rgb);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_FILM_GRAIN///////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef FILM_GRAINS
			#if FILM_GRAINS_STYLE==1
				color.rgba=clamp01(color.rgba);
				color.rgba=calcgrain(vec4(color.rgba));
			#endif

			#if FILM_GRAINS_STYLE==2
				color.rgb=filmgrain(color.rgb);
			#endif
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN_VISEUR///////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef VISEUR
			if(heldItemId==10261||heldItemId==10262||heldItemId==10344||heldItemId==10332||heldItemId==19999)aim(color.rgba);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN BANDES & CONCENTRATION///////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#if defined BANDES || defined CONCENTRATION

			#if defined BANDES || defined CONCENTRATION && defined BANDES
				float bottom = BOTTOMBAND;
				float top = TOPBAND;
			#endif

			#if defined CONCENTRATION && !defined BANDES
				float bottom = 0.0;
				float top = 0.0;
			#endif

			#if defined CONCENTRATION && defined BANDES
				float bottomplus = mix(bottom, BOTTOMBAND + BAND_ADDITION, sneakSmooth);
				float topplus = mix(top, TOPBAND + BAND_ADDITION, sneakSmooth);
			#endif

			#if defined CONCENTRATION && !defined BANDES
				float bottomplus = mix(bottom, CONCENTRATION_BAND, sneakSmooth);
				float topplus = mix(top, CONCENTRATION_BAND, sneakSmooth);
			#endif

			#if !defined CONCENTRATION && defined BANDES
				float bottomplus = bottom;
				float topplus = top;
			#endif

			float bottombandfade = clamp01((newtex.t - bottomplus) / 0.003);
			float topbandfade = clamp01((1.0 - newtex.t - topplus) / 0.003);

			if(bottomplus < 0.001) bottombandfade = 1.0;

			if(topplus < 0.001) topbandfade = 1.0;

			color.rgb = mix(vec3(0.0), color.rgb, bottombandfade * topbandfade);

		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////MAIN BARREL///////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef BARREL
			vec2 barrelTex = texCoord;
			barrelTex = distortBarrel(barrelTex, -0.2 * 0.5);

			float bottombandfade2 = clamp01((barrelTex.y) / 0.003);
			float topbandfade2 = clamp01((1.0 - barrelTex.y) / 0.003);

			float leftbandfade2 = clamp01((barrelTex.x) / 0.003);
			float rightbandfade2 = clamp01((1.0 - barrelTex.x) / 0.003);

			color.rgb = mix(vec3(0.0), color.rgb, bottombandfade2 * topbandfade2 * leftbandfade2 * rightbandfade2);

		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////BW_START////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef COLOR_START
		#include "/lib/color/starterColor.glsl"
			float animate  =min(starter, 0.1) * 10.0;
			vec3  start    =vec3(starterColor.rgb);
			      color.rgb=mix(start, color.rgb, animate);
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////SAHRPEN AA//////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////*/

		#ifdef SHARPEN_AA
            #if AA > 1
		    SharpenFilter(color.rgb, newtexcoord);
            #endif
		#endif

		/*////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////
		/////////////////////////////////////////END_MAIN///////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////////////////*/
		gl_FragColor=clamp01(color);
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	#ifdef DISTORTION
		uniform int isEyeInWater;
		uniform float aspectRatio;
		uniform mat4 gbufferProjection;
	#endif

	uniform mat4 gbufferModelView;

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	#ifdef DISTORTION
		const float strength=FOV_DISTORTION_STRENGTH;
		const float cylindricalRatio=1.0;
	#endif

	//Program//
	void main(){
		texCoord=gl_MultiTexCoord0.xy;

		gl_Position=ftransform();
		/*////////////////////////////////////////////////////////////////////////
		//////////////////////////////MAIN_DISTORTIONVSH/////////////////////////
		//////////////////////////////////////////////////////////////////////*/

		#ifdef DISTORTION
			float fov=atan(1.0 / gbufferProjection[1][1]);

			if(float(isEyeInWater)>0.9)fov*= 0.85;

			float height        =tan(fov / aspectRatio * 0.5);
			float scaledHeight  =strength * height;
			float cylAspectRatio=aspectRatio * cylindricalRatio;
			float aspectDiagSq  =aspectRatio * aspectRatio + 1.0;
			float diagSq        =scaledHeight * scaledHeight * aspectDiagSq;
			vec2  signedUV      =(2.0 * texCoord.st + vec2(-1.0, -1.0));

			float z =0.5 * sqrt(diagSq + 1.0) + 0.5;
			float ny=(z - 1.0) / (cylAspectRatio * cylAspectRatio +1.0);

			vUVDot =sqrt(ny) * vec2(cylAspectRatio, 1.0) * signedUV;
			vUV    =vec3(0.5, 0.5, 1.0) * z + vec3(-0.5, -0.5, 0.0);
			vUV.xy+=texCoord.st;
		#endif

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		      sunVec              =normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

		upVec=normalize(gbufferModelView[1].xyz);

	}

#endif