/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

//#define DEBUG_WATER

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying float mat;
varying float dist;

varying float isWater;

varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 binormal, tangent;
varying vec3 sunVec, upVec, eastVec;
varying vec3 viewVector;

varying vec4 color;
varying vec4 position;

varying mat3 moonRotMatrix;

#ifdef PLANET
varying mat3 planetRotMatrix;
#endif
#ifdef NEBULA
varying mat3 nebulaRotMatrix;
#endif
#ifdef GALAXY
varying mat3 galaxyRotMatrix;
#endif

#if defined ADVANCED_MATERIALS || defined NEW_NETHER_PORTAL
	varying vec4 vTexCoord, vTexCoordAM;
#endif

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform int heldItemId, heldItemId2;
	uniform int moonPhase;
	#define UNIFORM_MOONPHASE

	#ifdef DYNAMIC_HAND_LIGHT
		uniform int heldBlockLightValue;
		uniform int heldBlockLightValue2;
	#endif

	#ifndef WEATHER_PERBIOME
		uniform float isCold;
	#endif

	uniform float blindFactor, nightVision;
	uniform float far, near;
	uniform float frameTimeCounter;
	uniform float rainStrength;
	uniform float rainStrengthS;
	uniform float rainStrengthShiningStars;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;
	uniform float eyeAltitude;

	uniform ivec2 eyeBrightnessSmooth;

	uniform vec3 moonPosition;
	uniform vec3 cameraPosition, previousCameraPosition;
	uniform vec3 skyColor;
	uniform vec3 fogColor;

	uniform mat4 gbufferProjection, gbufferPreviousProjection, gbufferProjectionInverse;
	uniform mat4 gbufferModelView, gbufferPreviousModelView, gbufferModelViewInverse;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelView;

	uniform sampler2D texture;
	uniform sampler2D gaux2;
	uniform sampler2D depthtex1;
	uniform sampler2D depthtex2;
	uniform sampler2D noisetex;

	#ifdef PLANET
		uniform sampler2D colortex9;
	#endif

	#ifdef NEBULA
		uniform sampler2D colortex10;
	#endif

	#ifdef GALAXY
		uniform sampler2D colortex11;
	#endif

	#ifdef ADVANCED_MATERIALS
		uniform ivec2 atlasSize;
		uniform sampler2D specular;
		uniform sampler2D normals;

		#ifdef REFLECTION_RAIN
			uniform float wetness;
		#endif
	#endif

	#ifdef ENABLE_DARKNESS_EFFECT
		#if MC_VERSION >= 11900
			uniform float darknessLightFactor;
		#endif
	#endif

	//Common Variables//

	float eBS = eyeBrightnessSmooth.y / 240.0;
	float sunVisibility  = clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float moonVisibility = clamp00125(dot( -sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2 = clamp01(screenBrightness);

	#ifdef ADVANCED_MATERIALS
		vec2 dcdx = dFdx(texCoord);
		vec2 dcdy = dFdy(texCoord);
	#endif

	#ifdef OVERWORLD
		vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
	#else
		vec3 lightVec = sunVec;
	#endif

	//Common Functions//
	float GetLuminance(vec3 color){
		return dot(color,vec3(0.299, 0.587, 0.114));
	}

	float GetNoise(vec2 pos){
	return fract(sin(dot(pos,vec2(12.9898,4.1414)))*43758.5453);
	}

	float GetWaterHeightMap(vec3 worldPos, vec2 offset) {
		float noise = 0.0;

		vec2 wind = vec2(frameTimeCounter) * 0.5 * WATER_SPEED;

		worldPos.xz += worldPos.y * 0.25;

		#if WATER_NORMALS == 1
			offset /= 256.0;
			float noiseA = texture2D(noisetex, (worldPos.xz - wind) / 256.0 + offset).g;
			float noiseB = texture2D(noisetex, (worldPos.xz + wind) / 48.0 + offset).g;
		#elif WATER_NORMALS == 2
			offset /= 256.0;
			float noiseA = texture2D(noisetex, (worldPos.xz - wind) / 256.0 + offset).r;
			float noiseB = texture2D(noisetex, (worldPos.xz + wind) / 96.0 + offset).r;
			noiseA *= noiseA; noiseB *= noiseB;
		#endif

		#if WATER_NORMALS > 0
			noise = mix(noiseA, noiseB, WATER_DETAIL);
		#endif

		return noise * WATER_BUMP;
	}

	vec3 GetParallaxWaves(vec3 worldPos, vec3 viewVector) {
		vec3 parallaxPos = worldPos;

		for(int i = 0; i < 4; i++) {
			float height = -1.25 * GetWaterHeightMap(parallaxPos, vec2(0.0)) + 0.25;
			parallaxPos.xz += height * viewVector.xy / dist;
		}
		return parallaxPos;
	}

	vec3 GetWaterNormal(vec3 worldPos, vec3 viewPos, vec3 viewVector) {
		vec3 waterPos = worldPos + cameraPosition;

		#ifdef WATER_PARALLAX
			waterPos = GetParallaxWaves(waterPos, viewVector);
		#endif

		float normalOffset = WATER_SHARPNESS;

		float fresnel = pow(clamp01(1.0 + dot(normalize(normal), normalize(viewPos))), 8.0);
		float normalStrength = 0.35 * (1.0 - fresnel);

		float h1 = GetWaterHeightMap(waterPos, vec2( normalOffset, 0.0));
		float h2 = GetWaterHeightMap(waterPos, vec2(-normalOffset, 0.0));
		float h3 = GetWaterHeightMap(waterPos, vec2(0.0,  normalOffset));
		float h4 = GetWaterHeightMap(waterPos, vec2(0.0, -normalOffset));

		float xDelta = (h2 - h1) / normalOffset;
		float yDelta = (h4 - h3) / normalOffset;

		vec3 normalMap = vec3(xDelta, yDelta, 1.0 - (xDelta * xDelta + yDelta * yDelta));
		return normalMap * normalStrength + vec3(0.0, 0.0, 1.0 - normalStrength);
	}

	float WaterOp(float alpha, float difOP, float fresnel, float lViewPos) {

	float waterFogDistance = 1.0 - min(difOP / WATER_FOG_DENSITY, 0.25);
	waterFogDistance *= waterFogDistance;
	alpha = mix(0.97, alpha, min(waterFogDistance, 1.0 - fresnel));

	alpha = max(min(sqrt(lViewPos) * 0.075, 0.9), alpha);

	alpha = min(alpha, 1.0 - nightVision * 0.2);

	return alpha;
	}

	//Includes//

	#include "/lib/atmospherics/lunar.glsl"
	#include "/lib/atmospherics/skyimage.glsl"
	#include "/lib/color/blocklightColor.glsl"
	#include "/lib/color/dimensionColor.glsl"
	#include "/lib/color/skyColor.glsl"
	#include "/lib/color/specularColor.glsl"
	#include "/lib/color/waterColor.glsl"
	#include "/lib/util/dither.glsl"
	#include "/lib/atmospherics/waterFog.glsl"
	#include "/lib/util/spaceConversion.glsl"

	#ifdef OVERWORLD

		#ifdef AURORA
			#include "/lib/atmospherics/aurora.glsl"
		#endif

		#ifdef CLOUDS
			#include "/lib/atmospherics/ovclouds.glsl"
		#endif

		#ifdef SHININGSTARS
			#include "/lib/atmospherics/shiningstars.glsl"
		#endif

		#ifdef STARS
			#include "/lib/atmospherics/stars.glsl"
		#endif

		#ifdef SHOOTING_STARS
			#include "/lib/atmospherics/shootingstars.glsl"
		#endif

		#include "/lib/atmospherics/sky.glsl"

	#endif

	#if (defined OVERWORLD  && defined WATER_CAUSTICS)
			#include "/lib/lighting/caustics.glsl"
	#endif

	#include "/lib/atmospherics/fog.glsl"
	#include "/lib/lighting/forwardLighting.glsl"
	#include "/lib/surface/ggx.glsl"

	#ifndef KEEP_AA
	#include "/lib/reflections/raytracenokeepaa.glsl"
	#else
	#include "/lib/reflections/raytracekeepaa.glsl"
	#endif

	#include "/lib/reflections/simpleReflections.glsl"

	#if AA > 1
	#include "/lib/util/jitter.glsl"
	#endif

	#ifdef ADVANCED_MATERIALS
		#include "/lib/reflections/complexFresnel.glsl"
		#include "/lib/surface/directionalLightmap.glsl"
		#include "/lib/surface/materialGbuffers.glsl"
		#include "/lib/surface/parallax.glsl"

		#ifdef REFLECTION_RAIN
		#include "/lib/reflections/rainPuddles.glsl"
		#endif
	#endif

	#ifdef SHOW_DARK_ZONES
		#include "/lib/lighting/showdarkzones.glsl"
	#endif

	//Program//
	void main() {
		vec4 albedo = texture2D(texture, texCoord) * vec4(color.rgb, 1.0);
		vec3 newNormal = normal;
		float smoothness = 0.0;
		vec3 vlAlbedo = vec3(1.0);
		vec3 worldPos = vec3(0.0);
		vec4 cloud=vec4(0.0);

		#ifdef ADVANCED_MATERIALS
			vec2 newCoord = vTexCoord.st * vTexCoordAM.pq + vTexCoordAM.st;
			float surfaceDepth = 1.0;
			float parallaxFade = clamp01((dist - PARALLAX_DISTANCE) / 32.0);
			float skipAdvMat = float(mat > 0.98 && mat < 1.02);

			#ifdef PARALLAX
				if(skipAdvMat < 0.5) {
					newCoord = GetParallaxCoord(parallaxFade, surfaceDepth);
					albedo = texture2DGradARB(texture, newCoord, dcdx, dcdy) * vec4(color.rgb, 1.0);
				}
			#endif
		#endif

		vec2 lightmap = clampVec2_01(lmCoord);

		float skyRefFactor = 0.0;

		#if SKY_REFLECT_DARK_AREA == 1
			float lexSkyReflect = 0.99;
		#elif SKY_REFLECT_DARK_AREA == 2
			float lexSkyReflect = 0.88;
		#elif SKY_REFLECT_DARK_AREA == 3
			float lexSkyReflect = 0.85;
		#elif SKY_REFLECT_DARK_AREA == 4
			float lexSkyReflect = 0.80;
		#elif SKY_REFLECT_DARK_AREA == 5
			float lexSkyReflect = 0.50;
		#elif SKY_REFLECT_DARK_AREA == 6
			float lexSkyReflect = 0.0;
		#endif

		if (lightmap.y > lexSkyReflect) skyRefFactor = 1.0;

		if (albedo.a > 0.00001) {

			float water       = float(mat > 0.98 && mat < 1.02);
			float translucent = float(mat > 1.98 && mat < 2.52);
			float tintedGlass = float(mat > 2.23 && mat < 2.27);
			float ice      	  = float(mat > 3.98 && mat < 4.02);
			float netherportal= float(mat > 4.98 && mat < 5.02);

			float metalness      = 0.0;
			float emission       = 0.0;
			float subsurface     =tintedGlass * 0.25 + (translucent + water + ice);
			vec3 baseReflectance = vec3(0.04);

			#ifndef REFLECTION_TRANSLUCENT
				translucent = 0.0;
				tintedGlass = 0.0;
			#endif

			vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);

			#if AA > 1
				vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
			#else
				vec3 viewPos = ScreenToView(screenPos);
			#endif

			worldPos = ViewToWorld(viewPos);

			float lViewPos = length(viewPos.xyz);

			vec3 nViewPos = normalize(viewPos.xyz);

			float NdotU = dot(nViewPos, upVec);

			float dither = InterleavedGradientNoise();

			vec3 normalMap = vec3(0.0, 0.0, 1.0);

			mat3 tbnMatrix = mat3  (tangent.x, binormal.x, normal.x,
									tangent.y, binormal.y, normal.y,
									tangent.z, binormal.z, normal.z);

			#if WATER_NORMALS == 1 || WATER_NORMALS == 2
				if (water > 0.5) {
					normalMap = GetWaterNormal(worldPos, viewPos, viewVector);
					newNormal = clampVec3Inv_11(normalize(normalMap * tbnMatrix));
					float VdotN = dot(nViewPos, normalize(normal));
					if (VdotN > 0.0) newNormal = -newNormal;
				}
			#endif

			#ifdef ADVANCED_MATERIALS
				float f0 = 0.0, porosity = 0.5, ao = 1.0, skyOcclusion = 0.0;
				if (water < 0.5) {
					GetMaterials(smoothness, metalness, f0, emission, subsurface, porosity, ao, normalMap, newCoord, dcdx, dcdy);

					if (normalMap.x > -0.999 && normalMap.y > -0.999)
					newNormal = clampVec3Inv_11(normalize(normalMap * tbnMatrix));

				}
			#endif

	/*////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////NETHER_PORTAL//////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////*/
			#ifdef NEW_NETHER_PORTAL

				if (netherportal > 0.5) {

				lightmap = vec2(0.0);

				#if AA > 1
				dither = fract(dither + frameTimeCounter * 16.0);
				int sampleCount = 24;
				#else
				int sampleCount = 48;
				#endif

				float multiplier = 0.0525 / (-viewVector.z * sampleCount);

				vec2 interval = viewVector.xy * multiplier;

				vec2 coord = vTexCoord.st;

				vec4 albedoC = vec4(0.0);
				albedo *= 0.0;
				for (int i = 1; i <= sampleCount; i++) {
					coord += interval * PORTAL_PARALLAX_DEPTH;
					vec4 psample = texture2DLod(texture, fract(coord) * vTexCoordAM.pq + vTexCoordAM.st, 0.0);

					albedoC = max(albedoC, psample);

					psample.r *= PORTAL_RED_SAMPLES;
					psample.g *= PORTAL_GREEN_SAMPLES;
					psample.b *= PORTAL_BLUE_SAMPLES;
					psample.a = sqrt2(psample.a) * 0.999;

					albedo += psample * psample;
				}
				albedo /= sampleCount;

				#ifdef OVERWORLD
				float glowPowerMultiplier = NETHER_PORTAL_GLOWING_POWER_OVERWORLD;
				#endif

				#ifdef NETHER
				float glowPowerMultiplier = NETHER_PORTAL_GLOWING_POWER_NETHER * 0.05;
				#endif

				#ifdef END
				float glowPowerMultiplier = NETHER_PORTAL_GLOWING_POWER_ENDER * 0.05;
				#endif

				emission = albedoC.r * albedoC.b;
				emission *= emission;
				emission *= emission;
				emission = clamp(emission * glowPowerMultiplier * 12.0, 0.004,1.0);
				}
			#endif
	/*////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////NETHER_PORTAL//////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////*/

			if (water < 0.5) albedo.rgb = pow(albedo.rgb, vec3(2.2));

			float fresnel = clamp01(1.0 + dot(newNormal, nViewPos));
			float fresnelWR = pow(clamp01(1.0 + dot(newNormal, nViewPos)),3.0);
			float fresnelWR2=fresnelWR * fresnelWR;
			float fresnel2 = fresnel * fresnel;
			float fresnel4 = fresnel2 * fresnel2;

			float lViewPosOP = 0.0;
			float difOP = 0.0;
			vec3 colorTer = vec3(0.0);

			if (water > 0.5) {

			#if WATER_MODE == 0
				albedo.rgb = waterColor.rgb * waterColor.a * waterColor.a;

				#ifdef WATER_REVERB
					if (isEyeInWater == 1) {
					albedo.a = 1.0 - pow2(pow2(1.0 - albedo.a * min(fresnelWR2, 1.0)));
					albedo.a = max(albedo.a, 0.0002);
					}
				else
					albedo.a =WATER_A;
				#endif

			#elif WATER_MODE == 1
				albedo.rgb *= albedo.a;

			#elif WATER_MODE == 2
				float waterLuma = length(albedo.rgb / pow(color.rgb, vec3(2.2))) * 2.0;
				albedo.rgb = waterLuma * waterColor.rgb * waterColor.a * albedo.a;

			#elif WATER_MODE == 3
				albedo.rgb = color.rgb * color.rgb * 0.35;
			#endif

			if (isEyeInWater == 0) {
				#ifdef ABSORPTION
				colorTer = texture2D(gaux2, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).rgb;
				#endif
				vec2 texCoordOP = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
				float depthT = texture2D(depthtex1, texCoordOP).r;
				vec3 screenPosOP = vec3(texCoordOP, depthT);
				#if AA > 1
					vec3 viewPosOP = ScreenToView(vec3(TAAJitter(screenPosOP.xy, -0.5), screenPosOP.z));
				#else
					vec3 viewPosOP = ScreenToView(screenPosOP);
				#endif

				lViewPosOP = length(viewPosOP);
				difOP = (lViewPosOP - lViewPos);
				albedo.a = WaterOp(albedo.a, difOP, fresnel2, lViewPos);
			}

			baseReflectance = vec3(0.02);
		}

			#ifdef WHITE_WORLD
				#ifdef WATERW
					albedo.rgb = vec3(0.5);
				#endif
			#endif

			#ifdef BLACK_WORLD
				#ifdef WATERW
					albedo.rgb = vec3(0.0);
				#endif
			#endif

			if (water < 0.5) vlAlbedo = mix(vec3(1.0), albedo.rgb, sqrt1(albedo.a)) * (1.0 - pow(albedo.a, 64.0)) - vec3(0.002);
			else vlAlbedo = vec3(1.0, 1.0, 1.0);

			float NoL = clamp01(dot(newNormal, lightVec) * 1.01 - 0.01);
			float NoU = clampInv11(dot(newNormal, upVec));
			float NoE = clampInv11(dot(newNormal, eastVec));
			float vanillaDiffuse = (0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
			 	  vanillaDiffuse*= vanillaDiffuse;


			float parallaxShadow = 1.0;

			#ifdef ADVANCED_MATERIALS
				vec3 rawAlbedo = albedo.rgb * 0.999 + 0.001;
				albedo.rgb *= ao;

				#ifdef REFLECTION_SPECULAR
					albedo.rgb *= 1.0 - metalness * smoothness;
				#endif

				#ifdef SELF_SHADOW
					if (lightmap.y > 0.0 && NoL > 0.0 && water < 0.5) {
						parallaxShadow = GetParallaxShadow(surfaceDepth, parallaxFade, newCoord, lightVec, tbnMatrix);
						NoL *= parallaxShadow;
					}
				#endif

			#endif

			vec3 shadow = vec3(0.0);
			GetLighting(albedo.rgb, shadow, viewPos, worldPos, lightmap, color.a, NoL, vanillaDiffuse,
			parallaxShadow, emission, subsurface, 0.0, 1.0);

			/*/////////////////////////////////////////////
			/////Emin Water Absoption modified by me//////
			////////////Credits EminGT///////////////////
			//////////////////////////////////////////*/
			#ifdef ABSORPTION
			if (water > 0.5 && isEyeInWater == 0) {
				      colorTer       =colorTer * 2.0;
				      colorTer      *=colorTer;
				vec3  absorbColor    =(normalize(waterColor.rgb + vec3(0.01)) * sqrt(WATER_I)) * colorTer * 1.92;
				float absorbDist     =1.0 - clamp01(difOP / 8.0);
				vec3  waterAlbedoAbs =mix(absorbColor * absorbColor, colorTer * colorTer, absorbDist * absorbDist);
				      waterAlbedoAbs*=waterAlbedoAbs * 0.9;

				float waterFogAbs    =lViewPosOP / pow(far, 0.05) * 0.015 * (1.0 - sunVisibility * 0.25) * 2.5;
				      waterFogAbs    =(1.0 - (exp(-300.0 * pow(waterFogAbs*0.125, 3.25) * eBS)));
				float fixWaterFogAbs =max(1.0 - waterFogAbs, 0.0);
				      fixWaterFogAbs*=fixWaterFogAbs;
				      fixWaterFogAbs*=fixWaterFogAbs;
				      fixWaterFogAbs*=fixWaterFogAbs;
				      fixWaterFogAbs*=1.0 - rainStrengthS * 0.7;

				float skyLightFactor =clamp01(max(lightmap.y - 0.95, 0.05) * ALBEDO_ABS_POWER);
				float absorb         =(1.0 - albedo.a) * fixWaterFogAbs * skyLightFactor;
				      albedo.rgb     =mix(albedo.rgb, waterAlbedoAbs / (1.0 - WATER_ABS_COLOR), absorb);
				}
			#endif

			#ifdef ADVANCED_MATERIALS

				float puddles = 0.0;

				#if defined REFLECTION_RAIN && defined OVERWORLD
					#ifndef PUDDLES_ON_WATER
						if (water < 0.5 && wetness > 0.001)
					#else
						if (water > 0.5 && wetness > 0.001)
					#endif

					{
						puddles = GetPuddles(worldPos, newCoord, wetness) * clamp01(NoU) * skyRefFactor;
					}

					#ifdef WEATHER_PERBIOME
						float weatherweight = isCold + isDesert + isMesa + isSavanna;

						puddles *= 1.0 - weatherweight;

					#endif

					puddles *= clamp01(lightmap.y * 32.0 - 31.0);

					float ps = sqrt(1.0 - 0.75 * porosity);
					float pd = (0.5 * porosity + 0.15);

					smoothness = mix(smoothness, 1.0, puddles * ps);
					f0 = max(f0, puddles * 0.02);

					albedo.rgb *= 1.0 - (puddles * pd);

					if (puddles > 0.001 && rainStrengthS > 0.001) {
						mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
											tangent.y, binormal.y, normal.y,
											tangent.z, binormal.z, normal.z);

						vec3 puddleNormal = GetPuddleNormal(worldPos, viewPos, tbnMatrix);
						newNormal = normalize(mix(newNormal, puddleNormal, puddles * sqrt(1.0 - porosity) * rainStrengthS));
					}
				#endif
			#endif

			if (water > 0.5 || ice > 0.5 || (translucent > 0.5 && albedo.a < 0.95)){


				vec4 reflection = vec4(0.0);
				vec3 skyReflection = vec3(0.0);

				fresnel = fresnel4 * 0.95 + 0.05;
				fresnel*= max(1.0 - isEyeInWater * 0.5 * water, 0.5);
				fresnel*= 1.0 - translucent * (1.0 - albedo.a);
				fresnel*= FRESNEL;

				#ifdef REFLECTION
					reflection = SimpleReflection(viewPos, newNormal, dither);
					reflection.rgb = pow(reflection.rgb * 2.0, vec3(8.0));
				#endif


					if (ice > 0.5){
						fresnel *= fresnel4 * ICE_REFLECTION_STRENGTH;
					}

					if (reflection.a < 1.0) {

						vec3 skyRefPos = reflect(normalize(viewPos), newNormal);
						vec3 specularColor = GetSpecularColor(lightmap.y, 0.0, vec3(1.0));

						float volumetricsDither = InterleavedGradientNoise();

						#ifdef OVERWORLD
							skyReflection = GetSkyColor(skyRefPos, true);
						#endif

						#ifdef NETHER
							skyReflection = netherCol.rgb * 0.04;
						#endif

						#ifdef END
							skyReflection = endCol.rgb * 0.01;
						#endif

						#ifdef OVERWORLD
							vec3 specular = GetSpecularHighlight(newNormal, viewPos, lightVec, 0.9, vec3(0.02),
																specularColor, shadow, color.a);


							vec3 gotTheSkyColor = vec3(0.0);
							if (isEyeInWater == 0) gotTheSkyColor = GetSkyColor(skyRefPos, true);
							if (isEyeInWater == 1) gotTheSkyColor = 0.1 * pow(rawWaterColorSqrt.rgb * (1.0 - blindFactor), vec3(2.0));
							skyReflection = gotTheSkyColor;

							skyReflection += specular / ((4.0 - 3.0 * eBS) * fresnel * albedo.a);

							#if defined (OVERWORLD) && defined STARS && defined STARS_REFLECTION
								if (moonVisibility > 0.0){
										lightNight *= max(pow(fresnel/9, 2), 0.00001);
										vec3 stars = vec3(0.0);
										if(skyRefFactor > 0.5) stars = DrawStars(albedo.rgb, skyRefPos * 100.0);

										#if MC_VERSION >= 11605
											skyReflection += stars.rgb * WATER_STARS_REFLECTION_STRENGTH / 2.0;
										#else
											skyReflection += stars.rgb * WATER_STARS_REFLECTION_STRENGTH * 2.0;
										#endif
										lightNight /= max(pow(fresnel/9, 2), 0.00001);
								}
							#endif

							#if defined (OVERWORLD) && defined SHOOTING_STARS && defined SHOOTING_STARS_REFLECTION
								if (moonVisibility > 0.0){
											skyReflection += DrawShootingStar(albedo.rgb, skyRefPos * 100.0, 1.0,volumetricsDither);
								}
						#endif

						vec4 srpl = gbufferModelViewInverse*vec4(skyRefPos*100,1.0);
						srpl /= srpl.w;
						vec3 skyRefPosLunar = getLunarCoord(srpl.xyz);

						#if defined (OVERWORLD) && defined CLOUDS && defined CLOUDS_REFLECTION
							if (isEyeInWater == 0){
								vec4 cloud = DrawCloud(skyRefPos * 100.0, volumetricsDither, lightCol, ambientCol, 3);
								skyReflection = mix(skyReflection, cloud.rgb, cloud.a);
							}
						#endif

						#if defined (OVERWORLD) && defined SHININGSTARS && defined SHININGSTARS_REFLECTION
							if (moonVisibility > 0.0){
							#if defined CLOUDS && defined CLOUDS_REFLECTION
								float cloudMask = clamp01(cloud.a*50.0);
							#else
								float cloudMask = 0.0;
							#endif

									skyReflection = mix(skyReflection,DrawConstellations(skyReflection,skyRefPosLunar.xyz,volumetricsDither),
													(1.0-rainStrengthS)*(1.0-cloudMask)*moonVisibility*SHININGSTARS_REFLECTION_STRENGTH
													);
							}
						#endif


						#if defined (OVERWORLD) && defined PLANET && defined PLANET_REFLECTION
									skyReflection = mix(skyReflection.rgb,
														drawPlanetImage(skyReflection.rgb,skyReflection.rgb, vec2(0.2* PLANET_SIZE_X,0.2* PLANET_SIZE_Y), skyRefPosLunar.xyz, colortex9,PLANET_OPACITY),
														(1.0-rainStrengthS)*mix(PLANET_REFLECTION_STRENGTH_NIGHT,PLANET_REFLECTION_STRENGTH_DAY,sunVisibility)
													);
						#endif

						#if defined (OVERWORLD) && defined NEBULA && defined NEBULA_REFLECTION
							if (moonVisibility > 0.0){
									skyReflection = mix(skyReflection.rgb,
														drawNebulaImage(skyReflection.rgb, vec2(0.2* NEBULA_SIZE_X,0.2*NEBULA_SIZE_Y), skyRefPosLunar.xyz, colortex10,NEBULA_OPACITY),
														(1.0-rainStrengthS)*NEBULA_REFLECTION_STRENGTH_NIGHT
													);
							}
						#endif

						#if defined (OVERWORLD) && defined GALAXY && defined GALAXY_REFLECTION
							if (moonVisibility > 0.0){
									skyReflection = mix(skyReflection.rgb,
														drawGalaxyImage(skyReflection.rgb, vec2(0.2* GALAXY_SIZE_X,0.2*GALAXY_SIZE_Y), skyRefPosLunar.xyz, colortex11,GALAXY_OPACITY),
														(1.0-rainStrengthS)*GALAXY_REFLECTION_STRENGTH_NIGHT
													);
							}
						#endif

						#if defined (OVERWORLD) && defined AURORA && defined AURORA_REFLECTION
							if (moonVisibility > 0.0){
									skyReflection += DrawAurora(skyRefPos * 100.0, volumetricsDither, 8);
							}
						#endif

									skyReflection *= (4.0 - 3.0 * eBS) * lightmap.y;
						#endif

									skyReflection *= clamp01(1.0 - isEyeInWater) * skyRefFactor;

					}

				reflection.rgb = max(mix(skyReflection, reflection.rgb, reflection.a), vec3(0.0));

				albedo.rgb = mix(albedo.rgb, reflection.rgb, fresnel);
				albedo.a = mix(albedo.a, 1.0, fresnel);


			}else{

				#ifdef ADVANCED_MATERIALS
				skyOcclusion = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);

				baseReflectance = mix(vec3(f0), rawAlbedo, metalness);

				#ifdef REFLECTION_SPECULAR

				vec3 fresnel3 = vec3(0.0);

				if(netherportal < 0.5)

					fresnel3 = mix(baseReflectance, vec3(1.0), fresnel);

					#if MATERIAL_FORMAT == 0
						if (f0 >= 0.9 && f0 < 1.0) {
							baseReflectance = GetMetalCol(f0);
							fresnel3 = ComplexFresnel(pow(fresnel, 0.2), f0);
							#ifdef ALBEDO_METAL
								fresnel3 *= rawAlbedo;
							#endif
						}
					#endif

				float aoSquared = ao * ao;
					shadow *= aoSquared;
					fresnel3 *= aoSquared * smoothness * smoothness;

					if (smoothness > 0.0) {
						vec4 reflection = vec4(0.0);
						vec3 skyReflection = vec3(0.0);

						float ssrMask = clamp01(length(fresnel3) * 400.0 - 1.0);
						if(ssrMask > 0.0) reflection = SimpleReflection(viewPos, newNormal, dither);
						reflection.rgb = pow(reflection.rgb * 2.0, vec3(8.0));
						reflection.a *= ssrMask;

					if (reflection.a < 1.0){

					#ifdef OVERWORLD

						vec3 skyRefPos = reflect(normalize(viewPos.xyz), newNormal);
						skyReflection = GetSkyColor(skyRefPos, true);

							#if defined (OVERWORLD) && defined STARS && defined STARS_REFLECTION
								if (moonVisibility > 0.0){
											lightNight *= max(pow(fresnel/9, 2), 0.00001);
											vec3 stars = vec3(0.0);
											if(skyRefFactor > 0.5) stars = DrawStars(albedo.rgb, skyRefPos * 100.0);

										#if MC_VERSION >= 11605
											skyReflection += stars.rgb * WATER_STARS_REFLECTION_STRENGTH / 2.0;
										#else
											skyReflection += stars.rgb * WATER_STARS_REFLECTION_STRENGTH * 2.0;
										#endif
											lightNight /= max(pow(fresnel/9, 2), 0.00001);
								}
							#endif

							#if defined (OVERWORLD) && defined SHOOTING_STARS && defined SHOOTING_STARS_REFLECTION
								if (moonVisibility > 0.0){
										skyReflection += DrawShootingStar(albedo.rgb, skyRefPos * 100.0, 1.0,dither);
								}
							#endif

							vec4 srpl = gbufferModelViewInverse*vec4(skyRefPos*100,1.0);
							srpl /= srpl.w;
							vec3 skyRefPosLunar = getLunarCoord(srpl.xyz);


							#if (defined OVERWORLD || defined END) && defined CLOUDS && defined CLOUDS_REFLECTION
								if (isEyeInWater == 0){
									vec4 cloud = DrawCloud(skyRefPos * 100.0, dither, lightCol, ambientCol, 3);
									skyReflection = mix(skyReflection, cloud.rgb, cloud.a);
								}
							#endif


							#if defined (OVERWORLD) && defined SHININGSTARS && defined SHININGSTARS_REFLECTION
								if (moonVisibility > 0.0){
									#if defined CLOUDS && defined CLOUDS_REFLECTION
										float cloudMask = clamp01(cloud.a*50.0);
									#else
										float cloudMask = 0.0;
									#endif

									skyReflection = mix(skyReflection,DrawConstellations(skyReflection,skyRefPosLunar.xyz,dither),
													(1.0-rainStrengthS)*(1.0-cloudMask)*moonVisibility*SHININGSTARS_REFLECTION_STRENGTH
									);
								}
							#endif

							#if defined (OVERWORLD) && defined PLANET && defined PLANET_REFLECTION
								skyReflection = mix(skyReflection.rgb,
												drawPlanetImage(skyReflection.rgb,skyReflection.rgb, vec2(0.2* PLANET_SIZE_X,0.2* PLANET_SIZE_Y), skyRefPosLunar.xyz, colortex9,PLANET_OPACITY),
												(1.0-rainStrengthS)*mix(PLANET_REFLECTION_STRENGTH_NIGHT,PLANET_REFLECTION_STRENGTH_DAY,sunVisibility)
												);
							#endif

							#if defined (OVERWORLD) && defined NEBULA && defined NEBULA_REFLECTION
								if (moonVisibility > 0.0){
								skyReflection = mix(skyReflection.rgb,
													drawNebulaImage(skyReflection.rgb, vec2(0.2* NEBULA_SIZE_X,0.2*NEBULA_SIZE_Y), skyRefPosLunar.xyz, colortex10,NEBULA_OPACITY),
													(1.0-rainStrengthS)*NEBULA_REFLECTION_STRENGTH_NIGHT
												);
								}
							#endif

							#if defined (OVERWORLD) && defined GALAXY && defined GALAXY_REFLECTION
								if (moonVisibility > 0.0){
								skyReflection = mix(skyReflection.rgb,
													drawGalaxyImage(skyReflection.rgb, vec2(0.2* GALAXY_SIZE_X,0.2*GALAXY_SIZE_Y), skyRefPosLunar.xyz, colortex11,GALAXY_OPACITY),
													(1.0-rainStrengthS)*GALAXY_REFLECTION_STRENGTH_NIGHT
												);
								}
							#endif

							#if defined (OVERWORLD) && defined AURORA && defined AURORA_REFLECTION
								if (moonVisibility > 0.0){
								skyReflection += DrawAurora(skyRefPos * 100.0, dither, 8);
								}
							#endif

							float vanillaDiffuse = clamp(0.25 * dot(newNormal, upVec) + 0.75, 0.5, 1.0);
							vanillaDiffuse *= vanillaDiffuse;

								skyReflection = mix(
									vanillaDiffuse * minLightCol * ((isEyeInWater == 1) ? MINLIGHT_U_I : MINLIGHT_I),
									skyReflection * (4.0 - 3.0 * eBS),
									skyOcclusion
								);

					#endif

						#ifdef NETHER
							skyReflection = netherCol.rgb * 0.04;
						#endif

						#ifdef END
							skyReflection = endCol.rgb * 0.01;
						#endif
				}

							skyReflection *= skyRefFactor;
							reflection.rgb = max(mix(skyReflection, reflection.rgb, reflection.a), vec3(0.0));

							albedo.rgb = albedo.rgb * (1.0 - fresnel3 * (1.0 - metalness)) +
										reflection.rgb * fresnel3;
							albedo.a = mix(albedo.a, 1.0, GetLuminance(fresnel3));

			}
			#endif

				#if defined OVERWORLD || defined END
				vec3 specularColor = GetSpecularColor(lightmap.y, metalness, baseReflectance);

				albedo.rgb += GetSpecularHighlight(newNormal, viewPos, lightVec, smoothness, baseReflectance,
												specularColor, shadow * vanillaDiffuse, color.a);
				#endif
		#endif
		}

			if (tintedGlass > 0.5) {
				albedo.a = sqrt2(albedo.a);
			}

			#ifdef FOG
				Fog(albedo.rgb, viewPos.xyz);
			#endif

			#if (defined OVERWORLD  && defined WATER_CAUSTICS)
				#include "/lib/lighting/causticsCall.glsl"
			#endif

			#ifdef SHOW_DARK_ZONES
				if (vanillaDiffuse > 0.99 && (mat < 0.95 || mat > 1.05) && translucent < 0.5) {
					albedo.rgb=showDarkZones(albedo.rgb);
				}
			#endif
}

		/*DRAWBUFFERS:01*/

		#ifdef DEBUG_WATER
            gl_FragData[0]=vec4(0.5176, 0.0, 1.0, 0.75);
		#else
			gl_FragData[0] = vec4(albedo);
		#endif

		gl_FragData[1] = vec4(vlAlbedo, 1.0);

		#if MC_VERSION >= 11605

		/*DRAWBUFFERS:018*/
		gl_FragData[2] = vec4(vec3(isWater),1.0);

		#endif
}

#endif
//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	uniform float frameTimeCounter;
	uniform vec3 cameraPosition;

	uniform mat4 gbufferModelView,gbufferModelViewInverse;

	#if AA > 1
		uniform int frameCounter;
		uniform float viewWidth,viewHeight;
	#endif

	//Attributes//
	attribute vec4 mc_Entity;
	attribute vec4 mc_midTexCoord;
	attribute vec4 at_tangent;

	//Common Functions//
	float WavingWater(vec3 worldPos){
		float fractY=fract(worldPos.y+cameraPosition.y+0.005);

		#ifdef WAVING_WATER
			float wave=sin(6.28*(frameTimeCounter*0.7+worldPos.x*0.14+worldPos.z*0.07))+
					sin(6.28*(frameTimeCounter*0.5+worldPos.x*0.10+worldPos.z*0.20));
			if(fractY>0.01)return wave*0.0125;
		#endif

		return 0.0;
	}

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Includes//
	#include "/lib/util/moonrot.glsl"

	#if AA > 1
	#include "/lib/util/jitter.glsl"
	#endif

	//Program//
	void main(){

		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		lmCoord=(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
		lmCoord=clamp01((lmCoord - 0.03125) * 1.06667);

		normal  =normalize(gl_NormalMatrix * gl_Normal);
		binormal=normalize(gl_NormalMatrix * cross(at_tangent.xyz, gl_Normal.xyz) * at_tangent.w);
		tangent =normalize(gl_NormalMatrix * at_tangent.xyz);

		mat3 tbnMatrix=mat3(tangent.x,binormal.x,normal.x,
							tangent.y,binormal.y,normal.y,
							tangent.z,binormal.z,normal.z);

		viewVector=tbnMatrix * (gl_ModelViewMatrix * gl_Vertex).xyz;

		dist=length(gl_ModelViewMatrix * gl_Vertex);

		#if defined ADVANCED_MATERIALS || defined NEW_NETHER_PORTAL
		vec2 midCoord=(gl_TextureMatrix[0] * mc_midTexCoord).st;
		vec2 texMinMidCoord=texCoord - midCoord;

		vTexCoordAM.pq=abs(texMinMidCoord) * 2;
		vTexCoordAM.st=min(texCoord, midCoord - texMinMidCoord);

		vTexCoord.xy=sign(texMinMidCoord) * 0.5 + 0.5;
		#endif

		color=gl_Color;

		mat= 0.0;
		isWater = 0.0;

		if (mc_Entity.x == 10300) mat = 1.0, isWater = 1.0;	//Water Block
		if (mc_Entity.x == 10301 || mc_Entity.x == 10303) mat = 2.0; //Stained_glass / Stained_glass_pane
		if (mc_Entity.x == 10304) mat = 2.25; //Tinted_glass
		if (mc_Entity.x == 10302) mat = 4.0; //Ice Block

		/*////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////NETHER_PORTAL//////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////////////*/
		#ifdef NEW_NETHER_PORTAL
			float matEmissive = 5.0;
		#else
			float matEmissive = 2.0;
		#endif

		#ifdef OVERWORLD
			// Nether Portal
			if (mc_Entity.x == 10223)
			mat=matEmissive ,color.a *= 1.0;
		#endif

		#ifdef NETHER
			// Nether Portal
			if (mc_Entity.x == 10223)
			mat=matEmissive ,color.a *= 1.0;
		#endif

		#ifdef END
			// Nether Portal
			if (mc_Entity.x == 10223)
			mat=matEmissive ,color.a *= 1.0;
		#endif
		/*////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////NETHER_PORTAL//////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////////////////////*/

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994),-sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		vec3  usunvec             =vec3(-sin(ang), cos(ang) * sunRotationData);
		      sunVec              =normalize((gbufferModelView * vec4(usunvec * 2000.0, 1.0)).xyz);

		moonRotMatrix=getMoonRotMatrix(usunvec);

		#if defined (OVERWORLD) && defined PLANET
			planetRotMatrix=rotmat(PLANET_ROTX,PLANET_ROTY,PLANET_ROTZ);
		#endif

		#if defined (OVERWORLD) && defined NEBULA
			nebulaRotMatrix=rotmat(NEBULA_ROTX,NEBULA_ROTY,NEBULA_ROTZ);
		#endif

		#if defined (OVERWORLD) && defined GALAXY
			galaxyRotMatrix=rotmat(GALAXY_ROTX,GALAXY_ROTY,GALAXY_ROTZ);
		#endif

		upVec  =normalize(gbufferModelView[1].xyz);
		eastVec=normalize(gbufferModelView[0].xyz);

		vec4 position=gbufferModelViewInverse*gl_ModelViewMatrix*gl_Vertex;

		#ifdef WAVING_LIQUID
			float istopv = gl_MultiTexCoord0.t < mc_midTexCoord.t ? 1.0 : 0.0;
			if (mc_Entity.x == 10300) position.y += WavingWater(position.xyz);
		#endif

		gl_Position=gl_ProjectionMatrix*gbufferModelView*position;

		if (mat == 0.0) {
			gl_Position.z-=0.00001;
			lmCoord       =(lmCoord - 0.03125) * 1.06667;
		} else {
			lmCoord.y=(lmCoord.y - 0.03125) * 1.06667;
			lmCoord.x=smoothstep(0.0, 1.0, pow((lmCoord.x - 0.03125) * 0.55, 0.35));
		}

		lmCoord = clampVec2_01(lmCoord);

		#if AA > 1
			gl_Position.xy=TAAJitter(gl_Position.xy,gl_Position.w);
		#endif
	}

#endif