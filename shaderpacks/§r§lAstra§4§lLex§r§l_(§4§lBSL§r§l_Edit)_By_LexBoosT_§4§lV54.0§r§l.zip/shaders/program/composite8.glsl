/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying vec2 texCoord;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

    //Uniforms//
    #if defined OVERWORLD && defined FROSTED_LENS
    uniform float viewWidth, viewHeight;
    #endif

    uniform sampler2D colortex1;

    #if defined OVERWORLD && defined FROSTED_LENS
        #if MC_VERSION < 11605
            uniform sampler2D noisetex;
        #endif
        #if MC_VERSION >= 11605
            uniform sampler2D colortex12;
        #endif
    #endif

    #if defined OVERWORLD && defined FROSTED_LENS && defined FROSTED_LENS_ONLY_RAIN
	uniform float rainStrengthS2;
    #endif

    #if defined OVERWORLD && defined FROSTED_LENS

            uniform float biomeisColdSmooth;

    uniform ivec2 eyeBrightnessSmooth;
    uniform int isEyeInWater;
    #endif

    #if defined OVERWORLD && defined FROSTED_LENS && defined FROSTED_LENS_DYNAMIC_HAND_LIGHT && defined DYNAMIC_HAND_LIGHT
	uniform int heldItemId, heldItemId2;
	#endif

    //Common Functions//
    #if defined OVERWORLD && defined FROSTED_LENS
    float eBS2 = clamp01((eyeBrightnessSmooth.y-220)/15.0);
    #endif

    #if defined OVERWORLD && defined FROSTED_LENS

			float isColdSmooth = biomeisColdSmooth;

        float rand(vec2 uvFL) {

        uvFL = floor(uvFL*pow(10.0, 2.5))/pow(10.0, 2.5);

        float a = dot(uvFL, vec2(92.0, 80.0));
        float b = dot(uvFL, vec2(41.0, 62.0));

        float x = sin(a) + cos(b) * 51.0;
        return fract(x);
        }

        void GetFrostedLens(out vec4 FrozenLensCol){

            	vec4 handLightColFL = vec4(0.5255, 0.5255, 0.5255, 0.5)*1.0;

				#if defined FROSTED_LENS_DYNAMIC_HAND_LIGHT && defined DYNAMIC_HAND_LIGHT
                    if (heldItemId==13001||heldItemId2==13001|| //Glowstone, Torch, Jack'o Lantern, Lantern, Campfire, Shroomlight, Lava Bucket, Blaze Rod
                        heldItemId==13002||heldItemId2==13002|| //Beacon
                        heldItemId==13003||heldItemId2==13003|| //Redstone Torch
                        heldItemId==13004||heldItemId2==13004|| //Soul Lantern, Soul Campfire, Soul Torch
                        heldItemId==13005||heldItemId2==13005|| //Sea Lantern
                        heldItemId==13006||heldItemId2==13006|| //End Rod, Crying Obsidian, End Crystal, Nether Star
                        heldItemId==13007||heldItemId2==13007|| //Sea Pickle
                        heldItemId==13008||heldItemId2==13008||	//Conduit
						heldItemId==13009||heldItemId2==13009|| //Froglight ochre
						heldItemId==13010||heldItemId2==13010|| //Froglight Verdant
						heldItemId==13011||heldItemId2==13011){ //Froglight pearl


					#ifdef COLORED_DYNAMIC_HAND_LIGHT

                        if(heldItemId==13002||heldItemId2==13002)
                        {
                            handLightColFL=vec4(0.4863, 0.7686, 0.9882, 1.0);
                        }
                        else if(heldItemId==13003||heldItemId2==13003)
                        {
                            handLightColFL=vec4(0.8863, 0.0235, 0.0235, 1.0);
                        }
                        else if(heldItemId==13004||heldItemId2==13004)
                        {
                            handLightColFL=vec4(0.0, 0.1843, 1.0, 1.0);
                        }
                        else if(heldItemId==13005||heldItemId2==13005)
                        {
                            handLightColFL=vec4(0.0, 0.8549, 0.6667, 1.0);
                        }
                        else if(heldItemId==13006||heldItemId2==13006)
                        {
                            handLightColFL=vec4(0.9765, 0.3412, 1.0, 1.0);
                        }
                        else if(heldItemId==13007||heldItemId2==13007)
                        {
                            handLightColFL=vec4(0.8275, 0.8314, 0.4118, 1.0);
                        }
                        else if(heldItemId==13008||heldItemId2==13008)
                        {
                            handLightColFL=vec4(0.9922, 0.9255, 0.7059, 1.0);
                        }
                        else if(heldItemId==13009||heldItemId2==13009)
                        {
                            handLightColFL=vec4(0.8275, 0.8314, 0.4118, 1.0);
                        }
                        else if(heldItemId==13010||heldItemId2==13010)
                        {
                            handLightColFL=vec4(0.498, 0.8314, 0.4118, 1.0);
                        }
                        else if(heldItemId==13011||heldItemId2==13011)
                        {
                            handLightColFL=vec4(0.7294, 0.5412, 0.9725, 1.0);
                        }
                        else if(heldItemId==13001||heldItemId2==13001)
                        {
                            handLightColFL=vec4(1.0, 0.3686, 0.0, 1.0);
                        }
					#endif
				}
				#endif


                float frozenVisibility = eBS2;
                frozenVisibility *= isColdSmooth;

                #ifdef FROSTED_LENS_ONLY_RAIN
                frozenVisibility *= rainStrengthS2;
                #else
                #endif

                if (frozenVisibility < 0.1) frozenVisibility = 0.0;{

                //Noise
                vec2 uvFL=gl_FragCoord.xy / vec2(viewWidth, viewHeight);

                #if MC_VERSION < 11605
                    vec4 frost=texture2D(noisetex, uvFL) * frozenVisibility;
                #endif
                #if  MC_VERSION >=11605
                vec4 frost =texture2D(colortex12, uvFL) * frozenVisibility;
                #endif

                vec2 rnd=vec2(rand(uvFL + frost.r * 0.5), rand(uvFL + frost.b * 0.5));

                //Vignette
                vec2  lens    =vec2(0.5 * 7.5, 0.05);
                float dist    =distance(uvFL.xy, vec2(0.5,0.5));
                float vignette=pow(1.0 - smoothstep(lens.x, lens.y, dist),2.0);

                //Rendu Final
                rnd *= frost.rg * vignette * FROSTYNESS;
                rnd *= 1.0 - floor(vignette);

                uvFL += rnd;

                //Coloration Vignette
                FrozenLensCol = mix(texture2D(colortex1, uvFL), handLightColFL, COLORIZE * vec4(rnd.r));
                }
        }
    #endif

    //Program//
    void main(){

        vec4 color = texture2D(colortex1, texCoord);

        #if defined OVERWORLD && defined FROSTED_LENS
        GetFrostedLens(color);
        #endif

        /*DRAWBUFFERS:1*/
        gl_FragData[0] = vec4(color);

    }

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

    //Program//
    void main(){
        texCoord=gl_MultiTexCoord0.xy;

        gl_Position=ftransform();
    }

#endif