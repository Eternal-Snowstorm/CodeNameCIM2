/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying vec2 texCoord;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform float viewWidth, viewHeight, aspectRatio;
	uniform int frameCounter;
	uniform sampler2D colortex0;

	#if BLOOM_DIMENSION > 0
		uniform float rainStrengthS;
		uniform ivec2 eyeBrightnessSmooth;
		uniform int isEyeInWater;
	#endif

	//Optifine Constants//
	const bool colortex0MipmapEnabled = true;

	//Common Variables//
	float ph = 0.8 / min(360.0, viewHeight);
	float pw = ph / aspectRatio;

	float weight[7] = float[7](0.0315, 0.1102, 0.2205, 0.2756, 0.2205, 0.1102, 0.0315);

	//Common Functions//
	vec3 BloomTile(float lod, vec2 coord, vec2 offset) {
	vec3 bloom = vec3(0.0), temp = vec3(0.0);
	float scale = exp2(lod);
	coord = (coord - offset) * scale;
	float padding = 0.5 + 0.005 * scale;

	if (abs(coord.x - 0.5) < padding && abs(coord.y - 0.5) < padding) {
		for(int i = 0; i < 7; i++) {
			for(int j = 0; j < 7; j++) {
				float wg = weight[i] * weight[j];
				vec2 pixelOffset = vec2((float(i) - 3.0) * pw, (float(j) - 3.0) * ph);
				vec2 sampleCoord = coord + pixelOffset * scale;
				bloom += texture2D(colortex0, sampleCoord).rgb * wg;
			}
		}
	}

	return pow(bloom / 32.0, vec3(0.25));
}

#include "/lib/util/dither.glsl"

	//Program//
	void main(){
	vec2 bloomCoord = texCoord * viewHeight * 0.8 / min(360.0, viewHeight);


				#if BLOOM_DIMENSION ==1

					#if defined NETHER || defined END
					vec3 blur =BloomTile(1.0, bloomCoord, vec2(0.0      , 0.0   ));
					     blur+=BloomTile(2.0, bloomCoord, vec2(0.51     , 0.0   ));
					     blur+=BloomTile(3.0, bloomCoord, vec2(0.51     , 0.26  ));
					     blur+=BloomTile(4.0, bloomCoord, vec2(0.645    , 0.26  ));
					     blur+=BloomTile(5.0, bloomCoord, vec2(0.7175   , 0.26  ));
					     blur+=BloomTile(6.0, bloomCoord, vec2(0.645    , 0.3325));
					     blur+=BloomTile(7.0, bloomCoord, vec2(0.670625 , 0.3325)) * 0.6;
						 blur = clamp(blur + (Bayer64(gl_FragCoord.xy) - 0.5) / 384.0, vec3(0.0), vec3(1.0));
					#else

					vec3 blur =BloomTile(1.0, bloomCoord, vec2(0.0      , 0.0   ));
					     blur+=BloomTile(2.0, bloomCoord, vec2(0.51     , 0.0   ));
					     blur+=BloomTile(3.0, bloomCoord, vec2(0.51     , 0.26  ));
					     blur+=BloomTile(4.0, bloomCoord, vec2(0.645    , 0.26  ));
					     blur+=BloomTile(5.0, bloomCoord, vec2(0.7175   , 0.26  ));
					     blur+=BloomTile(6.0, bloomCoord, vec2(0.645    , 0.3325));
					     blur+=BloomTile(7.0, bloomCoord, vec2(0.670625 , 0.3325));
						 blur = clamp(blur + (Bayer64(gl_FragCoord.xy) - 0.5) / 384.0, vec3(0.0), vec3(1.0));
					#endif
				#endif

		/* DRAWBUFFERS:1 */

		#if BLOOM_DIMENSION > 0

			gl_FragData[0] = vec4(blur, 1.0);

		#else

			gl_FragData[0] = vec4(1.0);

		#endif
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Program//
	void main(){
		texCoord=gl_MultiTexCoord0.xy;

		gl_Position=ftransform();
	}

#endif