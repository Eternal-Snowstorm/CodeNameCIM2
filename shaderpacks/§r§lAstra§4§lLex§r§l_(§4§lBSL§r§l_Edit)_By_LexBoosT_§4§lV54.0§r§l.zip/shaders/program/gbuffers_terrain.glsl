/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

//#define DEBUG_TERRAIN

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying float mat;

#ifdef EMISSIVE_RECOLOR
varying float recolor;
#endif

#ifdef DETECTEUR_CAVE
varying float visibleblock;
#endif

varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 sunVec, upVec, eastVec;

varying vec4 color;
varying vec4 position;

#ifdef ADVANCED_MATERIALS
	varying float dist;

	varying vec3 binormal, tangent;
	varying vec3 viewVector;

	varying vec4 vTexCoord, vTexCoordAM;
#endif

#ifdef SHOW_DARK_ZONES
	varying float isLightSource;
#endif

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform int frameCounter;
	uniform int blockEntityId;
	uniform int isEyeInWater;
	uniform int heldItemId;
	uniform int heldItemId2;
	uniform int moonPhase;
	#define UNIFORM_MOONPHASE

	#ifdef DYNAMIC_HAND_LIGHT
		uniform int heldBlockLightValue;
		uniform int heldBlockLightValue2;
	#endif

	uniform float frameTimeCounter;
	uniform float nightVision;
	uniform float rainStrengthS;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;
	uniform float far;

	#ifdef ENABLE_DARKNESS_EFFECT
		#if MC_VERSION >= 11900
			uniform float darknessFactor;
			uniform float darknessLightFactor;
		#endif
	#endif

	uniform ivec2 eyeBrightnessSmooth;

	uniform mat4 gbufferProjectionInverse;
	uniform mat4 gbufferModelViewInverse;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelView;
	uniform vec3 cameraPosition;
	uniform sampler2D texture;
	uniform sampler2D noisetex;

	#ifdef ADVANCED_MATERIALS
		uniform ivec2 atlasSize;
		uniform sampler2D specular;
		uniform sampler2D normals;

		#ifdef REFLECTION_RAIN
			uniform float wetness;
			uniform mat4 gbufferModelView;
		#endif

	#endif

	uniform vec3 fogColor;

	//Common Variables//

	float eBS              =eyeBrightnessSmooth.y / 240.0;
	float sunVisibility    =clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float moonVisibility   =clamp00125(dot( -sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2=clamp01(screenBrightness);

	#ifdef ADVANCED_MATERIALS
		vec2 dcdx = dFdx(texCoord);
		vec2 dcdy = dFdy(texCoord);
	#endif

	#ifdef OVERWORLD
		vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
	#else
		vec3 lightVec = sunVec;
	#endif

	//Common Functions//
	float GetLuminance(vec3 color){
		return dot(color,vec3(0.299, 0.587, 0.114));
	}

	//Includes//
	#include "/lib/color/blocklightColor.glsl"
	#include "/lib/color/dimensionColor.glsl"
	#include "/lib/color/specularColor.glsl"
	#include "/lib/util/dither.glsl"
	#include "/lib/util/spaceConversion.glsl"

	#if (defined OVERWORLD  && defined WATER_CAUSTICS)
	#include "/lib/color/waterColor.glsl"
	#include "/lib/lighting/caustics.glsl"
	#endif

	#include "/lib/lighting/forwardLighting.glsl"


	#if AA > 1
	#include "/lib/util/jitter.glsl"
	#endif

	#ifdef ADVANCED_MATERIALS
	#include "/lib/util/encode.glsl"
	#include "/lib/surface/ggx.glsl"
	#include "/lib/reflections/complexFresnel.glsl"

	#ifdef DIRECTIONAL_LIGHTMAP
	#include "/lib/surface/directionalLightmap.glsl"
	#endif

	#include "/lib/surface/materialGbuffers.glsl"
	#include "/lib/surface/parallax.glsl"

	#ifdef REFLECTION_RAIN
	#include "/lib/reflections/rainPuddles.glsl"
	#endif

	#endif

	#ifdef SHOW_DARK_ZONES
	#include "/lib/lighting/showdarkzones.glsl"
	#endif

	//Program//
	void main(){

		#ifdef DETECTEUR_CAVE
			if(visibleblock>0.5){
		#endif

			vec4 detectcolor = texture2D(texture, texCoord);
			vec4 albedo = detectcolor * vec4(color.rgb, 1.0);
			vec3 newNormal = normal;
			float smoothness = 0.0;
			float material = floor(mat);

			#ifdef ADVANCED_MATERIALS
				vec2 newCoord = vTexCoord.st * vTexCoordAM.pq + vTexCoordAM.st;
				float surfaceDepth = 1.0;
				float parallaxFade = clamp01((dist - PARALLAX_DISTANCE) / 32.0);
				float skipAdvMat = float(mat > 2.98 && mat < 3.02);

				#ifdef PARALLAX
					if(skipAdvMat < 0.5){
						newCoord = GetParallaxCoord(parallaxFade, surfaceDepth);
						detectcolor = texture2DGradARB(texture, newCoord, dcdx, dcdy);
						albedo = detectcolor * vec4(color.rgb, 1.0);
					}
				#endif

				float skyOcclusion = 0.0;

				vec3 fresnel3 = vec3(0.0);

			#endif

			if (albedo.a > 0.00001){

				vec2 lightmap = clampVec2_01(lmCoord);

				float foliage      =float(mat > 0.98 && mat < 1.02);
				float leaves       =float(mat > 1.48 && mat < 1.52);
				float emissive     =float(mat > 1.98 && mat < 2.02);
				float lava         =float(mat > 2.98 && mat < 3.02);
				float redstoneb    =float(mat > 3.02 && mat < 4.02);
				float lapilazul    =float(mat > 4.02 && mat < 5.02);
				float candle       =float(mat > 5.02 && mat < 6.02);
				float berries      =float(mat > 6.98 && mat < 7.02);
				float spore_blossom=float(mat > 7.98 && mat < 8.02);
				float lantern      =float(mat > 8.98 && mat < 9.02);
				float soullantern  =float(mat > 9.98 && mat < 10.02);
				float lichen       =float(mat > 10.98 && mat < 11.02);
				float sea_pickle   =float(mat > 11.98 && mat < 12.02);
				float beacon       =float(mat > 12.98 && mat < 13.02);
				float sametyst     =float(mat > 13.98 && mat < 14.02);
				float mametyst     =float(mat > 14.98 && mat < 15.02);
				float lametyst     =float(mat > 15.98 && mat < 16.02);
				float ametystc     =float(mat > 16.98 && mat < 17.02);
				float enchtable    =float(mat > 17.98 && mat < 18.02);
				float magma        =float(mat > 18.98 && mat < 19.02);
				float sculk_cat	   =float(mat > 19.98 && mat < 20.02);
				float sculk_sens_a =float(mat > 20.98 && mat < 21.02);
				float snow  	   =float(mat > 21.98 && mat < 22.02);
				float sand  	   =float(mat > 22.98 && mat < 23.02);

				float metalness=0.0;
				float emission =(emissive
									+ candle
									+ lava
									+ lantern
									+ soullantern
									+ beacon
									+ sametyst
									+ mametyst
									+ lametyst
									+ ametystc
									+ enchtable
									+ magma
									+ sculk_cat
									+ sculk_sens_a) * 0.5;

				float subsurface = 0.0;
				vec3 baseReflectance = vec3(0.04);

				if (sunVisibility>0.0){
				subsurface = leaves * SUBSURFACE_LEAVES_INTENSITY_DAY + foliage * SUBSURFACE_FOLIAGE_INTENSITY_DAY;
				}
				if (moonVisibility>0.0){
				subsurface = leaves * SUBSURFACE_LEAVES_INTENSITY_NIGHT + foliage * SUBSURFACE_FOLIAGE_INTENSITY_NIGHT;
				}

				vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
				#if AA > 1
					vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
				#else
					vec3 viewPos = ScreenToView(screenPos);
				#endif
					vec3 worldPos = ViewToWorld(viewPos);

				#ifdef ADVANCED_MATERIALS
					float f0 = 0.0, porosity = 0.5, ao = 1.0;
					vec3 normalMap = vec3(0.0, 0.0, 1.0);
					GetMaterials(smoothness, metalness, f0, emission, subsurface, porosity, ao, normalMap, newCoord, dcdx, dcdy);

					mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
										tangent.y, binormal.y, normal.y,
										tangent.z, binormal.z, normal.z);

					if (normalMap.x > -0.999 && normalMap.y > -0.999)
					newNormal = clampVec3Inv_11(normalize(normalMap * tbnMatrix));

					#ifdef REDSTONE_BLOCK_EMISSIVE
						if (redstoneb > 0.5) emission = 1.0, albedo.r *= 1.0, lightmap = vec2(0.7);
					#endif

					#ifdef LAPISLAZUL_BLOCK_EMISSIVE
						if (lapilazul > 0.5) emission = 1.0, albedo.b *= 1.0, lightmap = vec2(0.7);
					#endif

				#endif

			/*////////COLOR_POINTER////////////*/
			#include "/lib/color/colorpointer.glsl"
			/*////////COLOR_POINTER////////////*/

				albedo.rgb = pow(albedo.rgb, vec3(2.2));

				float ec = GetLuminance(albedo.rgb) * 1.7;
				#ifdef EMISSIVE_RECOLOR
					if (recolor > 0.5){
						albedo.rgb = blocklightCol * pow(ec, 1.5) / (BLOCKLIGHT_I * BLOCKLIGHT_I);
						albedo.rgb /= 0.7 * albedo.rgb + 0.7;
					}
					if (lava > 0.02){
						albedo.rgb = pow(blocklightCol * ec / BLOCKLIGHT_I, vec3(2.0));
						albedo.rgb /= 0.5 * albedo.rgb + 0.5;
					}
				#else
				#endif

				#ifdef WHITE_WORLD
					#ifdef TERRAINW
						albedo.rgb = vec3(0.5);
					#endif
				#endif

				#ifdef BLACK_WORLD
					#ifdef TERRAINW
						albedo.rgb = vec3(0.0);
					#endif
				#endif

				vec3 outNormal = newNormal;

				#ifdef NORMAL_PLANTS
					if(foliage > 0.5){
					newNormal = upVec;

					#ifdef ADVANCED_MATERIALS
						newNormal = normalize(mix(outNormal, newNormal, normalMap.z * normalMap.z));
					#endif
					}
				#endif

				float NoL            =clamp01(dot(newNormal, lightVec) * 1.01 - 0.01);
				float NoU            =clampInv11(dot(newNormal, upVec));
				float NoE            =clampInv11(dot(newNormal, eastVec));
				float vanillaDiffuse =(0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
				      vanillaDiffuse*=vanillaDiffuse;

				#ifndef NORMAL_PLANTS
					if (foliage > 0.5) vanillaDiffuse *= 1.8;
				#endif

				float smoothLighting = color.a;

				float parallaxShadow = 1.0;
				#ifdef ADVANCED_MATERIALS
					vec3 rawAlbedo = albedo.rgb * 0.999 + 0.001;
					albedo.rgb *= ao;

					#ifdef REFLECTION_SPECULAR
						albedo.rgb *= 1.0 - metalness * smoothness * 0.65;
					#endif

					float doParallax = 0.0;

					#ifdef SELF_SHADOW
						float pNoL = dot(outNormal, lightVec);

						#ifdef OVERWORLD
							doParallax = float(lightmap.y > 0.0 && pNoL > 0.0);
						#endif

						#ifdef END
							doParallax = float(pNoL > 0.0);
						#endif

						if (doParallax > 0.5 && skipAdvMat < 0.5){
							parallaxShadow = GetParallaxShadow(surfaceDepth, parallaxFade, newCoord, lightVec, tbnMatrix);
						}
					#endif

					#ifdef DIRECTIONAL_LIGHTMAP
						mat3 lightmapTBN = GetLightmapTBN(viewPos);
						lightmap.x = DirectionalLightmap(lightmap.x, lmCoord.x, outNormal, lightmapTBN);
						lightmap.y = DirectionalLightmap(lightmap.y, lmCoord.y, outNormal, lightmapTBN);
					#endif

				#endif

				vec3 shadow = vec3(0.0);

				GetLighting(albedo.rgb, shadow, viewPos, worldPos, lightmap, smoothLighting, NoL, vanillaDiffuse,
				parallaxShadow, emission, subsurface, leaves, 0.0);

				#ifdef ADVANCED_MATERIALS
					float puddles = 0.0;

					#if defined REFLECTION_RAIN && defined OVERWORLD

					float pNoU = dot(outNormal, upVec);

					if(wetness > 0.001) {
					puddles = GetPuddles(worldPos, newCoord, wetness) * clamp01(pNoU);
					}

					#ifdef WEATHER_PERBIOME
						float weatherweight = isCold + isDesert + isMesa + isSavanna;
						puddles *= 1.0 - weatherweight;
					#endif

					#if DISABLE_PUDDLES == 0
						puddles *= clamp01(lightmap.y * 32.0 - 31.0) * (1.0 - lava);
					#endif

					#if DISABLE_PUDDLES == 1
						puddles *= clamp01(lightmap.y * 32.0 - 31.0) * (1.0 - lava) * (1.0 - snow);
					#endif

					#if DISABLE_PUDDLES == 2
						puddles *= clamp01(lightmap.y * 32.0 - 31.0) * (1.0 - lava) * (1.0 - snow) * (1.0 - sand);
					#endif

					float ps = sqrt(1.0 - 0.75 * porosity);
					float pd = (0.5 * porosity + 0.15);

					smoothness = mix(smoothness, 1.0, puddles * ps);
					f0 = max(f0, puddles * 0.02);

					albedo.rgb *= 1.0 - (puddles * pd);

					if (puddles > 0.001 && rainStrengthS > 0.001){
						mat3 tbnMatrix = mat3(tangent.x, binormal.x, normal.x,
											tangent.y, binormal.y, normal.y,
											tangent.z, binormal.z, normal.z);

						vec3 puddleNormal = GetPuddleNormal(worldPos, viewPos, tbnMatrix);
						newNormal = normalize(mix(outNormal, puddleNormal, puddles * sqrt(1.0 - porosity) * rainStrengthS));
					}
				#endif

				skyOcclusion = lightmap.y * lightmap.y * (3.0 - 2.0 * lightmap.y);

				baseReflectance = mix(vec3(f0), rawAlbedo, metalness);
				float fresnel = pow(clamp01(1.0 + dot(newNormal, normalize(viewPos.xyz))), 5.0);

				fresnel3 = mix(baseReflectance, vec3(1.0), fresnel);
					#if MATERIAL_FORMAT == 1
						if (f0 >= 0.9 && f0 < 1.0) {
							baseReflectance = GetMetalCol(f0);
							fresnel3 = ComplexFresnel(pow(fresnel, 0.2), f0);

							#ifdef ALBEDO_METAL
								fresnel3 *= rawAlbedo;
							#endif
						}
					#endif


				float aoSquared = ao * ao;
					shadow *= aoSquared; fresnel3 *= aoSquared;
					albedo.rgb = albedo.rgb * (1.0 - fresnel3 * smoothness * smoothness * (1.0 - metalness));


				#if defined OVERWORLD && (defined ADVANCED_MATERIALS || defined SPECULAR_HIGHLIGHT_ROUGH)

					vec3 specularColor = GetSpecularColor(lightmap.y, metalness, baseReflectance);

					albedo.rgb += GetSpecularHighlight(newNormal, viewPos, lightVec, smoothness, baseReflectance,
												specularColor, shadow * vanillaDiffuse, color.a);
				#endif

				#if defined ADVANCED_MATERIALS && defined REFLECTION_SPECULAR && defined REFLECTION_ROUGH
					if (normalMap.x > -0.999 && normalMap.y > -0.999){
						normalMap = mix(vec3(0.0, 0.0, 1.0), normalMap, smoothness);
						newNormal = mix(normalMap * tbnMatrix, newNormal, 1.0 - pow(1.0 - puddles, 4.0));
						newNormal = clampVec3Inv_11(normalize(newNormal));
					}
					#endif
				#endif

				#if defined WATER_CAUSTICS && defined OVERWORLD
				#include "/lib/lighting/causticsCall.glsl"
				#endif

				#ifdef SHOW_DARK_ZONES
					if (vanillaDiffuse > 0.99) {
						if(isLightSource < 0.5)
						albedo.rgb=showDarkZones(albedo.rgb);
					}
				#endif

			} else albedo.a = 0.0;


			/*DRAWBUFFERS:0*/

			#ifdef DEBUG_TERRAIN
            	gl_FragData[0]=vec4(0.0, 1.0, 0.949, 0.75);
			#else
				gl_FragData[0] = vec4(albedo);
			#endif

			#if defined ADVANCED_MATERIALS && defined REFLECTION_SPECULAR

			/*DRAWBUFFERS:0361*/
			gl_FragData[1]=vec4(smoothness,skyOcclusion, 0.0, 1.0);
			gl_FragData[2]=vec4(EncodeNormal(newNormal), float(gl_FragCoord.z<1.0), 1.0);
			gl_FragData[3]=vec4(fresnel3, 1.0);

			#endif

			#ifdef DETECTEUR_CAVE
		}
		else
		{
			discard;
		}
			#endif

	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	uniform float frameTimeCounter;

	uniform vec3 cameraPosition;

	uniform mat4 gbufferModelView,gbufferModelViewInverse;
	uniform mat4 gbufferProjection;

	#if AA > 1
		uniform int frameCounter;
		uniform float viewWidth,viewHeight;
	#endif

	//Attributes//
	attribute vec4 mc_Entity;
	attribute vec4 mc_midTexCoord;

	#ifdef ADVANCED_MATERIALS
	attribute vec4 at_tangent;
	#endif

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	float GetNoise(vec2 pos){
	return fract(sin(dot(pos,vec2(12.9898,4.1414)))*43758.5453);
	}

	//Includes//
	#include "/lib/vertex/waving.glsl"

	#if AA > 1
	#include "/lib/util/jitter.glsl"
	#endif

	//Program//
	void main(){

		#ifdef DETECTEUR_CAVE
			if(mc_Entity.x==10003||mc_Entity.x==10002||mc_Entity.x==10999){

					visibleblock=0.0;
				}else{
					visibleblock=1.0;
				}
		#endif

		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		lmCoord=(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
		lmCoord=clamp01((lmCoord - 0.03125) * 1.06667);

		normal=normalize(gl_NormalMatrix * gl_Normal);

		#ifdef ADVANCED_MATERIALS
			binormal=normalize(gl_NormalMatrix * cross(at_tangent.xyz, gl_Normal.xyz) * at_tangent.w);
			tangent=normalize(gl_NormalMatrix * at_tangent.xyz);

			mat3 tbnMatrix=mat3(tangent.x,binormal.x,normal.x,
								tangent.y,binormal.y,normal.y,
								tangent.z,binormal.z,normal.z);

			viewVector=tbnMatrix * (gl_ModelViewMatrix * gl_Vertex).xyz;

			dist=length(gl_ModelViewMatrix * gl_Vertex);

			vec2 midCoord=(gl_TextureMatrix[0] * mc_midTexCoord).st;
			vec2 texMinMidCoord= texCoord - midCoord;

			vTexCoordAM.pq=abs(texMinMidCoord) * 2;
			vTexCoordAM.st=min(texCoord, midCoord - texMinMidCoord);

			vTexCoord.xy=sign(texMinMidCoord) * 0.5 + 0.5;
		#endif

		color=gl_Color;

		mat=0.0;

		#ifdef EMISSIVE_RECOLOR
			recolor=0.0;
		#endif

		#ifdef SHOW_DARK_ZONES
			isLightSource=0.0;
		#endif

		if (mc_Entity.x == 10100 || mc_Entity.x == 10101 || mc_Entity.x == 10102 || mc_Entity.x == 10103 ||
			mc_Entity.x == 10104 || mc_Entity.x == 10107 || mc_Entity.x == 10108 || mc_Entity.x == 10109 ||
			mc_Entity.x == 10111 || mc_Entity.x == 10112 || mc_Entity.x == 10113 || mc_Entity.x == 10114 ||
			mc_Entity.x == 10302 ||	mc_Entity.x == 10303 ||	mc_Entity.x == 10304 || mc_Entity.x == 10401 ||
			mc_Entity.x == 10702 ||	mc_Entity.x == 10702 ||	mc_Entity.x == 10703 || mc_Entity.x == 10704 )
			mat = 1.0;

		if (mc_Entity.x == 10105 || mc_Entity.x == 10106){
			mat = 1.5;
			color.rgb *= 1.225;
		}

		if (mc_Entity.x == 10200 || mc_Entity.x == 10207 || mc_Entity.x == 10210 || mc_Entity.x == 10214 ||
			mc_Entity.x == 10215 || mc_Entity.x == 10216 || mc_Entity.x == 10226 || mc_Entity.x == 10231 ||
			mc_Entity.x == 10249 || mc_Entity.x == 10251 || mc_Entity.x == 10252 ||	mc_Entity.x == 10253 ||
			mc_Entity.x == 10254 || mc_Entity.x == 10258 || mc_Entity.x == 10265 || mc_Entity.x == 10266 ||
			mc_Entity.x == 10267 || mc_Entity.x == 10268 || mc_Entity.x == 10269)
			mat = 2.0;

		#ifdef SHOW_DARK_ZONES
		if (mc_Entity.x == 10200 || mc_Entity.x == 10207 || mc_Entity.x == 10210 || mc_Entity.x == 10214 ||
			mc_Entity.x == 10215 || mc_Entity.x == 10216 || mc_Entity.x == 10217 || mc_Entity.x == 10218 ||
			mc_Entity.x == 10219 || mc_Entity.x == 10222 || mc_Entity.x == 10226 || mc_Entity.x == 10231 ||
			mc_Entity.x == 10248 || mc_Entity.x == 10249 || mc_Entity.x == 10250 || mc_Entity.x == 10251 ||
			mc_Entity.x == 10252 ||	mc_Entity.x == 10253 || mc_Entity.x == 10254 || mc_Entity.x == 10255 ||
			mc_Entity.x == 10257 || mc_Entity.x == 10258 || mc_Entity.x == 10259 || mc_Entity.x == 10888 )
			isLightSource = 1.0;
		#endif

		/*////////////////////////////////////////////////////////////////////////////
		////////////////////////BLOCK BRIGHTNESS MENU//////////////////////////////
		//////////////////////////////////////////////////////////////////////////*/
		#include "/lib/color/sculk_sensor_active_color.glsl"
		#include "/lib/vertex/blockbrightness.glsl"
		/*///////////////////////////////////////////////////////////////////////////
		////////////////////////BLOCK BRIGHTNESS MENU//////////////////////////////
		//////////////////////////////////////////////////////////////////////////*/

		if (mc_Entity.x == 10245) // Furnace
			lmCoord.x -= 0.0667;

		if (mc_Entity.x == 10400) // lectern
			color.a = 1.0;

		if (mc_Entity.x == 10996 || mc_Entity.x == 10997) // snow
			mat = 22.0;
		
		if (mc_Entity.x == 10998 || mc_Entity.x == 10999) // sand
			mat = 23.0;

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		      sunVec              =normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

		upVec  =normalize(gbufferModelView[1].xyz);
		eastVec=normalize(gbufferModelView[0].xyz);

		vec4 position=gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

		float istopv=gl_MultiTexCoord0.t < mc_midTexCoord.t ? 1.0 : 0.0;
		position.xyz=WavingBlocks(position.xyz, istopv);

		gl_Position = gl_ProjectionMatrix * gbufferModelView * position;

		#if AA > 1
			gl_Position.xy=TAAJitter(gl_Position.xy, gl_Position.w);
		#endif

	}

#endif