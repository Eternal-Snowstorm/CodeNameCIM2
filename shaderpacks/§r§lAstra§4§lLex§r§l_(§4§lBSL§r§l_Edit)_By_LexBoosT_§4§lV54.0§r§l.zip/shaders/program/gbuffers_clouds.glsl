/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

//#define DEBUG_CLOUDS

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
#if !defined CLOUDS && defined OVERWORLD
	varying vec2 texCoord;

	varying vec3 normal;
	varying vec3 sunVec, upVec;

#endif

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	#if !defined CLOUDS && defined OVERWORLD
		uniform int isEyeInWater;

		uniform float rainStrengthS;
		uniform float screenBrightness;
		uniform float viewWidth, viewHeight;
		uniform ivec2 eyeBrightnessSmooth;

		uniform vec3 cameraPosition;

		uniform sampler2D texture;

		uniform mat4 gbufferProjectionInverse;
		uniform mat4 gbufferModelViewInverse;
		uniform mat4 shadowProjection;
		uniform mat4 shadowModelView;

		#if AA > 1
			uniform int frameCounter;
		#endif
	#endif

	//Common Variables//
	#if !defined CLOUDS && defined OVERWORLD
	float eBS              =eyeBrightnessSmooth.y / 240.0;
	float sunVisibility    =clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float moonVisibility   =clamp00125(dot( -sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2=clamp01(screenBrightness);
	#endif

	//Includes//
	#if !defined CLOUDS && defined OVERWORLD
		#include "/lib/color/lightColor.glsl"
		#include "/lib/util/spaceConversion.glsl"
		#include "/lib/color/skyColor.glsl"

		#if AA > 1
			#include "/lib/util/jitter.glsl"
		#endif
	#endif
	//Program//
	void main(){
		#if !defined CLOUDS && defined OVERWORLD
			vec4 albedo = vec4(1.0, 1.0, 1.0, texture2D(texture, texCoord.xy).a);
			vec3 texture = texture2D(texture, texCoord.xy).rgb;
			albedo.rgb = pow(albedo.rgb * texture, vec3(2.2));

			float timeBrightnessS = 1.0 - timeBrightness;
			timeBrightnessS = 1.0 - timeBrightnessS * timeBrightnessS;
			if (rainStrengthS < 1.0) albedo.rgb *= lightCol * sky_ColorSqrt * (0.75 + 0.15 * timeBrightnessS);
			float sunVisibility2 = sunVisibility * sunVisibility;
			if (rainStrengthS > 0.0) {
				vec3 rainColor = weatherCol.rgb * weatherCol.rgb * (0.002 + 0.03 * timeBrightnessS + 0.02 * sunVisibility2);
				albedo.rgb = mix(albedo.rgb, rainColor * texture, rainStrengthS);
			}
			if (albedo.a > 0.1) {
				albedo.a = VANILLA_CLOUD_OPACITY;
			}

			vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
			#if AA > 1
				vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
			#else
				vec3 viewPos = ScreenToView(screenPos);
			#endif

			vec3 worldPos = ViewToWorld(viewPos);
			float lWorldPos = length(worldPos.xz);
			float cloudDistance = 320.0;
			cloudDistance = clamp((cloudDistance - lWorldPos) / cloudDistance, 0.0, 1.0);
			if (cloudDistance < 0.00001) discard;
			albedo.a *= min(cloudDistance * 1.0, 1.0);

			vec3 nViewPos = normalize(viewPos.xyz);
			float NdotU = dot(nViewPos, upVec);
			float cosS = dot(nViewPos, sunVec);

			float scattering = 0.5 * sunVisibility2 * pow(cosS * 0.5 * (2.0 * sunVisibility - 1.0) + 0.8, 6.0);

			albedo.rgb *= 1.0 + scattering * (1.0 - rainStrengthS * 0.8);

			float absFactorP = min((1.0 - min(moonBrightness, 0.6) / 0.6) * 0.115, 0.075);
			vec3 cloudColor = vec3(0.0);
			if (cosS > 0.0) {
				float absNdotU = 1.0 - abs(NdotU);
				float absFactor = absFactorP * absNdotU * cosS * absNdotU * 15.0 * (1.0 - rainStrengthS);
				cloudColor = mix(lightMorning, lightEvening, mefade);
				cloudColor *= cloudColor;
				cloudColor *= cloudColor;
				cloudColor *= cloudColor;
				cloudColor *= absFactor * absFactor;
			}
			albedo.rgb += cloudColor * 0.25;

			float vanillaDiffuse = clamp(0.25 * dot(normal, upVec) + 0.75, 0.5, 1.0);
			albedo.rgb *= vanillaDiffuse;

			vec3 vlAlbedo = mix(vec3(1.0), albedo.rgb, sqrt1(albedo.a)) * (1.0 - pow(albedo.a, 64.0));
		#else
			discard;

			vec4 albedo = vec4(1.0);
			vec3 vlAlbedo = vec3(1.0);

		#endif

		/*DRAWBUFFERS:01*/
		#ifdef DEBUG_CLOUDS
            gl_FragData[0]=vec4(0.549, 0.0, 1.0, 0.75);
		#else
			gl_FragData[0] = clamp01(albedo);
		#endif

		gl_FragData[1] = vec4(vlAlbedo, 1.0);
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	#if !defined CLOUDS && defined OVERWORLD
		#if AA > 1
			uniform int frameCounter;
			uniform float viewWidth;
			uniform float viewHeight;
		#include "/lib/util/jitter.glsl"
		#endif

		uniform mat4 gbufferModelView;
		uniform mat4 gbufferModelViewInverse;
	#endif

	//Common Variables//
	#if !defined CLOUDS && defined OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Program//
	void main(){
		#if !defined CLOUDS && defined OVERWORLD
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		normal=normalize(gl_NormalMatrix * gl_Normal);

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		      sunVec              =normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

		upVec=normalize(gbufferModelView[1].xyz);

		gl_Position=ftransform();

			#if AA > 1
				gl_Position.xy=TAAJitter(gl_Position.xy, gl_Position.w);
			#endif
		#else

		gl_Position = vec4(0.0);

		return;
	#endif
	}

#endif