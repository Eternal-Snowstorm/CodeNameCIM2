/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying vec2 texCoord, lmCoord;
varying vec3 upVec, sunVec;
varying vec4 position;
varying vec4 color;
//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	#if AA > 1
	uniform int frameCounter;
	#endif

	uniform float rainStrengthS;
	uniform float rainStrengthS2;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;

	#if defined OVERWORLD && defined WEATHER_DYNAMIC_HAND_LIGHT && defined DYNAMIC_HAND_LIGHT
	uniform int heldItemId, heldItemId2;
	uniform int heldBlockLightValue;
	uniform int heldBlockLightValue2;
	#endif

	uniform mat4 gbufferModelViewInverse;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelView;

	uniform int moonPhase;
	#define UNIFORM_MOONPHASE

	uniform ivec2 eyeBrightnessSmooth;

	uniform mat4 gbufferProjectionInverse;

	uniform sampler2D texture;
	uniform sampler2D depthtex0;

	//Common Variables//

	float eBS              =eyeBrightnessSmooth.y / 240.0;
	float sunVisibility    =clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float moonVisibility   =clamp00125(dot( -sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2=clamp01(screenBrightness);

	//Common Functions//
	void Defog(inout vec3 albedo){
		float z=texture2D(depthtex0,gl_FragCoord.xy/vec2(viewWidth,viewHeight)).r;
		if (z == 1.0) return;

		vec4 screenPos =vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight), z, 1.0);
		vec4 viewPos   =gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
		     viewPos  /=viewPos.w;

		float fog        =length(viewPos) * OVERWORLD_FOG_DENSITY / 256.0;
		float clearDay   =sunVisibility * (1.0 - rainStrengthS);
		      fog       *=(0.5 * rainStrengthS + 1.0) / (3.0 * clearDay + 1.0);
		      fog        =1.0 - exp(-2.0 * pow(fog, 0.25 * clearDay + 1.25) * eBS);
		      albedo.rgb/=1.0 - fog;
	}

	//Includes//
	#include "/lib/color/lightColor.glsl"
	#include "/lib/color/blocklightColor.glsl"

	#if AA > 1
	#include "/lib/util/jitter.glsl"
	#endif

	#include "/lib/util/spaceConversion.glsl"

	//Program//
	void main(){
		#if defined NETHER || defined END
		discard;
		#endif

		vec4 albedo = texture2D(texture, texCoord.xy);
		vec2 lightmap = lmCoord;

		#if defined OVERWORLD && defined WEATHER
			 	albedo.a = texture2D(texture, texCoord).a;
				lightmap.x = max(lightmap.x * lightmap.y - 0.15, 0.0);

			if (albedo.a > 0.0){
				vec3 screenPos = vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);

				#if AA > 1
					vec3 viewPos = ScreenToView(vec3(TAAJitter(screenPos.xy, -0.5), screenPos.z));
				#else
					vec3 viewPos = ScreenToView(screenPos);
				#endif

				vec3  worldPos          =ViewToWorld(viewPos);
				float lViewPos          =length(viewPos.xyz);
				float torchDist         =length(worldPos);
				float handTorchLightmap2=0.0;
				vec3  handLightCol      =vec3(0.1);

				#if defined WEATHER_DYNAMIC_HAND_LIGHT && defined DYNAMIC_HAND_LIGHT
					float handLight = max(float(heldBlockLightValue), float(heldBlockLightValue2));
					float handLightFactor = clamp((handLight - 2.0 * lViewPos) / 15.0, 0.0, 0.9333);
					lightmap.x = max(lightmap.x, handLightFactor);
				#endif

				#if defined WEATHER_DYNAMIC_HAND_LIGHT && defined DYNAMIC_HAND_LIGHT
					if (heldItemId==13001||heldItemId2==13001|| //Glowstone, Torch, Jack'o Lantern, Lantern, Campfire, Shroomlight, Lava Bucket, Blaze Rod
						heldItemId==13002||heldItemId2==13002|| //Beacon
						heldItemId==13003||heldItemId2==13003|| //Redstone Torch
						heldItemId==13004||heldItemId2==13004|| //Soul Lantern, Soul Campfire, Soul Torch
						heldItemId==13005||heldItemId2==13005|| //Sea Lantern
						heldItemId==13006||heldItemId2==13006|| //End Rod, Crying Obsidian, End Crystal, Nether Star
						heldItemId==13007||heldItemId2==13007|| //Sea Pickle
						heldItemId==13008||heldItemId2==13008||	//Conduit
						heldItemId==13009||heldItemId2==13009|| //Froglight ochre
						heldItemId==13010||heldItemId2==13010|| //Froglight Verdant
						heldItemId==13011||heldItemId2==13011){ //Froglight pearl

					handTorchLightmap2=clamp01(1.0-((DIST_DECLINE*2.0 - DIST_MAX_LIGHT*2.0)/(torchDist-DIST_MAX_LIGHT*2.0)))*MAX_LIGHT;

					#ifdef COLORED_DYNAMIC_HAND_LIGHT

						if(heldItemId==13002||heldItemId2==13002)
						{
							handLightCol=vec3(0.4863, 0.7686, 0.9882);
						}
						else if(heldItemId==13003||heldItemId2==13003)
						{
							handLightCol=vec3(0.8863, 0.0235, 0.0235);
						}
						else if(heldItemId==13004||heldItemId2==13004)
						{
							handLightCol=vec3(0.0, 0.1843, 1.0);
						}
						else if(heldItemId==13005||heldItemId2==13005)
						{
							handLightCol=vec3(0.0, 0.8549, 0.6667);
						}
						else if(heldItemId==13006||heldItemId2==13006)
						{
							handLightCol=vec3(0.9765, 0.3412, 1.0);
						}
						else if(heldItemId==13007||heldItemId2==13007)
						{
							handLightCol=vec3(0.8275, 0.8314, 0.4118);
						}
						else if(heldItemId==13008||heldItemId2==13008)
						{
							handLightCol=vec3(0.9922, 0.9255, 0.7059);
						}
						else if(heldItemId==13009||heldItemId2==13009)
						{
							handLightCol=vec3(0.8275, 0.8314, 0.4118);
						}
						else if(heldItemId==13010||heldItemId2==13010)
						{
							handLightCol=vec3(0.4941, 0.8314, 0.4118);
						}
						else if(heldItemId==13011||heldItemId2==13011)
						{
							handLightCol=vec3(0.7294, 0.5412, 0.9725);
						}
						else if(heldItemId==13001||heldItemId2==13001)
						{
							handLightCol=vec3(1.0, 0.3686, 0.0);
						}
					#endif
				}
				#endif

				albedo.a *= 0.25 * rainStrengthS2 * length(albedo.rgb / 8.0) * float(albedo.a > 0.1);

				#if CUSTOM_RAIN_SNOW_COLORING == 1
					albedo.rgb *= (finalRainSnowCol.rgb + lightmap.x * lightmap.x * (blocklightCol * mix(10.0, 10.0, moonVisibility)) + ((handLightCol * mix(1.0, 4.0, moonVisibility)) * handTorchLightmap2)) * (WEATHER_OPACITY * mix(1.0, 0.1, moonVisibility));
				#else
					albedo.rgb *= (ambientCol2 + lightmap.x * lightmap.x * (blocklightCol * mix(4.0, 2.0, moonVisibility)) + ((handLightCol * mix(1.0, 0.5, moonVisibility)) * handTorchLightmap2)) * WEATHER_OPACITY;
				#endif

				#if (defined OVERWORLD || defined END || defined NETHER) && defined FOG && MC_VERSION <= 11500
					if (gl_FragCoord.z > 0.991) Defog(albedo.rgb);
				#endif
			}
		#endif

		/*DRAWBUFFERS:0*/
		gl_FragData[0] = vec4(albedo);
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	#if defined OVERWORLD && defined NOUVELLE_PLUIE
		uniform vec3 cameraPosition;
	#endif

	uniform mat4 gbufferModelView;
	uniform mat4 gbufferModelViewInverse;
	uniform float frameTimeCounter;

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Program//
	void main(){

		position=gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
		float frameTimeCounter2=frameTimeCounter*2.0;

		#if defined OVERWORLD && defined NOUVELLE_PLUIE
			vec3 worldpos            =position.xyz + cameraPosition;
			bool istopv              =worldpos.y > cameraPosition.y + 5.0;
			if  (!istopv)position.xz+= vec2(0.2, 0.2) + sin(frameTimeCounter2) * sin(frameTimeCounter2) * sin(frameTimeCounter2) * vec2(0.1, 0.1);
			     position.xz        -=(vec2(0.3, 0.2) + sin(frameTimeCounter2) * sin(frameTimeCounter2) * sin(frameTimeCounter2) * vec2(0.2, 0.1)) * 0.10;
			     position.xz        -=(vec2(0.4, 0.2) + sin(frameTimeCounter2) * sin(frameTimeCounter2) * sin(frameTimeCounter2) * vec2(0.3, 0.1)) * 0.08;
			     position.xz        -=(vec2(0.5, 0.2) + sin(frameTimeCounter2) * sin(frameTimeCounter2) * sin(frameTimeCounter2) * vec2(0.4, 0.1)) * 0.06;
		#endif

		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		lmCoord=(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
		lmCoord=clamp01((lmCoord - 0.03125) * 1.06667);

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		      sunVec              =normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

		upVec=normalize(gbufferModelView[1].xyz);

		gl_Position=gl_ProjectionMatrix * gbufferModelView * position;

		color = gl_Color;

	}

#endif