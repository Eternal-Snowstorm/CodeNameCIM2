/*//////////////////////////////////////////////////////////////////////////////
//    ##      #####   ######   ######     ##     ####     #######  ##  ##     //
//   ####    ##   ##  # ## #    ##  ##   ####     ##       ##   #  ##  ##     //
//  ##  ##   #          ##      ##  ##  ##  ##    ##       ## #     ####      //
//  ##  ##    #####     ##      #####   ##  ##    ##       ####      ##       //
//  ######        ##    ##      ## ##   ######    ##   #   ## #     ####      //
//  ##  ##   ##   ##    ##      ##  ##  ##  ##    ##  ##   ##   #  ##  ##     //
//  ##  ##    #####    ####    #### ##  ##  ##   #######  #######  ##  ##     //
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//      #####   ##   ##    ##     #####    #######  ######    #####           //
//     ##   ##  ##   ##   ####     ## ##    ##   #   ##  ##  ##   ##          //
//     #        ##   ##  ##  ##    ##  ##   ## #     ##  ##  #                //
//      #####   #######  ##  ##    ##  ##   ####     #####    #####           //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//          ##  ##   ##  ######    ##  ##   ## #     ## ##        ##          //
//     ##   ##  ##   ##  ##  ##    ## ##    ##   #   ##  ##  ##   ##          //
//      #####   ##   ##  ##  ##   #####    #######  #### ##   #####           //
/////(BSL Shaders Edit)//////////////////////////////////////By LexBoosT//////*/

//Settings//

//#define DEBUG_TEXTURED

#include "/lib/util/fastMath.glsl"

#include "/settings/globalSettings.glsl"

//Varyings//
varying vec2 texCoord, lmCoord;

varying vec3 normal;
varying vec3 sunVec, upVec, eastVec;

varying vec4 color;

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

	//Uniforms//
	uniform int frameCounter;
	uniform int isEyeInWater;
	uniform int heldItemId;
	uniform int heldItemId2;

	#ifdef DYNAMIC_HAND_LIGHT
		uniform int heldBlockLightValue;
		uniform int heldBlockLightValue2;
	#endif

	uniform float far, near;
	uniform float frameTimeCounter;
	uniform float blindFactor, nightVision;
	uniform float rainStrength;
	uniform float rainStrengthS;
	uniform float screenBrightness;
	uniform float viewWidth, viewHeight;

	uniform ivec2 eyeBrightnessSmooth;
	uniform ivec2 atlasSize;

	uniform sampler2D noisetex;

	uniform vec3 cameraPosition;

	uniform vec3 skyColor;
	uniform vec3 fogColor;

	uniform mat4 gbufferProjectionInverse;
	uniform mat4 gbufferModelViewInverse;
	uniform mat4 shadowProjection;
	uniform mat4 shadowModelView;

	uniform sampler2D texture;

	#if MC_VERSION >= 11700
		uniform ivec4 blendFunc;
	#endif

	#ifdef SOFT_PARTICLES
		uniform sampler2D depthtex0;
	#endif

	#ifdef ENABLE_DARKNESS_EFFECT
		#if MC_VERSION >= 11900
			uniform float darknessLightFactor;
		#endif
	#endif

	//Common Variables//

	float eBS              =eyeBrightnessSmooth.y / 240.0;
	float sunVisibility    =clamp00125(dot( sunVec,upVec) + 0.0625) * 8.0;
	float moonVisibility   =clamp00125(dot( -sunVec,upVec) + 0.0625) * 8.0;
	float screenBrightness2=clamp01(screenBrightness);

	#ifdef OVERWORLD
		vec3 lightVec = sunVec * ((timeAngle < 0.5325 || timeAngle > 0.9675) ? 1.0 : -1.0);
	#else
		vec3 lightVec = sunVec;
	#endif

	//Common Functions//
	float GetLuminance(vec3 color){
		return dot(color,vec3(0.299, 0.587, 0.114));
	}

	#ifdef SOFT_PARTICLES
		float GetLinearDepth(float depth) {
			return (2.0 * near) / (far + near - depth * (far - near));
		}
	#endif

	//Includes//
	#if defined NETHER || defined END
		#include "/lib/color/lightColor.glsl"
	#endif

	#include "/lib/color/blocklightColor.glsl"
	#include "/lib/color/dimensionColor.glsl"
	#include "/lib/color/skyColor.glsl"
	#include "/lib/color/waterColor.glsl"
	#include "/lib/util/dither.glsl"
	#include "/lib/atmospherics/waterFog.glsl"
	#include "/lib/util/spaceConversion.glsl"
	#include "/lib/atmospherics/sky.glsl"
	#include "/lib/atmospherics/fog.glsl"
	#include "/lib/lighting/forwardLighting.glsl"

	#if (defined OVERWORLD  && defined WATER_CAUSTICS)
	#include "/lib/lighting/caustics.glsl"
	#endif

	//Program//
	void main(){
		vec4 albedo = vec4(0.0);
		vec4 albedoT = texture2D(texture, texCoord);
			albedo = albedoT * color;
		vec3 vlAlbedo = vec3(1.0);


		if (albedo.a > 0.0){
			vec2 lightmap=clampVec2_01(lmCoord);

			vec3  screenPos=vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z);
			vec3  viewPos  =ScreenToView(screenPos);
			vec3  worldPos =ViewToWorld(viewPos);
			float lViewPos =length(viewPos);

			#if MC_VERSION >= 11700
				if (blendFunc == ivec4(770, 1, 1, 0)) {
					albedo.a = albedoT.a * color.a * 0.2;
					lightmap = vec2(1.0);
				}
			#endif

			albedo.rgb = pow(albedo.rgb, vec3(2.2));

			#ifdef WHITE_WORLD
				#ifdef TEXTURESW
				albedo.rgb = vec3(0.5);
				#endif
			#endif

			#ifdef BLACK_WORLD
				#ifdef TEXTURESW
					albedo.rgb = vec3(0.0);
				#endif
			#endif

			float NoL            =1.0;
			      NoL            =clamp01(dot(normal, lightVec) * 1.01 - 0.01);
			float NoU            =clampInv11(dot(normal, upVec));
			float NoE            =clampInv11(dot(normal, eastVec));
			float vanillaDiffuse =(0.25 * NoU + 0.75) + (0.667 - abs(NoE)) * (1.0 - abs(NoU)) * 0.15;
			      vanillaDiffuse*=vanillaDiffuse;

			vec3 shadow = vec3(0.0);
			GetLighting(albedo.rgb, shadow, viewPos, worldPos, lightmap, 1.0, NoL, 1.0,
			1.0, 0.0, 0.0, 0.0, 1.0);

			albedo.rgb *= 2.0;

			#if defined FOG && MC_VERSION >= 11500
			vlAlbedo = mix(vec3(1.0), albedo.rgb, sqrt1(albedo.a)) * (1.0 - pow(albedo.a, 64.0));
				Fog(albedo.rgb, viewPos);
			#endif

			#if (defined OVERWORLD  && defined WATER_CAUSTICS)
				#include "/lib/lighting/causticsCall.glsl"
			#endif

		}else discard;

		#ifdef SOFT_PARTICLES
			float linearZ    =GetLinearDepth(gl_FragCoord.z) * (far - near);
			float backZ      =texture2D(depthtex0, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).r;
			float linearBackZ=GetLinearDepth(backZ) * (far - near);

			float difference=clamp(linearBackZ - linearZ, 0.5, 1.0);
			      difference=difference * difference * (3.0 - 2.0 * difference);

			float opaqueThreshold=InterleavedGradientNoise();

			if (albedo.a > 0.999) albedo.a *= float(difference > opaqueThreshold);
			else albedo.a *= difference;
		#endif



		/*DRAWBUFFERS:017*/

		#ifdef DEBUG_TEXTURED
            gl_FragData[0]=vec4(0.0353, 1.0, 0.0, 0.75);
		#else
			gl_FragData[0] = vec4(albedo);
		#endif

		gl_FragData[1] = vec4(vlAlbedo, 1.0);
		gl_FragData[2] = vec4(1.0, 1.0, 1.0, 1.0);

		#ifdef ADVANCED_MATERIALS
		/*DRAWBUFFERS:01736*/
		gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
		gl_FragData[3] = vec4(0.0, 0.0, 0.0, 1.0);
		#endif
	}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

	//Uniforms//
	uniform float frameTimeCounter;

	uniform vec3 cameraPosition;

	uniform mat4 gbufferModelView,gbufferModelViewInverse;

	#ifdef SOFT_PARTICLES
		uniform float far,near;
	#endif

	//Common Functions//
	#ifdef SOFT_PARTICLES
		float GetLinearDepth(float depth) {
		return (2.0 * near) / (far + near - depth * (far - near));
		}
		float GetLogarithmicDepth(float depth) {
			return -(2.0 * near / depth - (far + near)) / (far - near);
		}
	#endif

	//Common Variables//
	#ifdef OVERWORLD
		float timeAngleM = timeAngle;
	#else
		float timeAngleM = 0.25;
	#endif

	//Program//
	void main(){
		texCoord=(gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

		lmCoord=(gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
		lmCoord=clamp01((lmCoord - 0.03125) * 1.06667);

		normal=normalize(gl_NormalMatrix * gl_Normal);

		color=gl_Color;

		const vec2 sunRotationData=vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
		float ang                 =fract(timeAngleM - 0.25);
		      ang                 =(ang+(cos(ang * 3.14159265358979) * - 0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
		      sunVec              =normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) *2000.0, 1.0)).xyz);

		upVec  =normalize(gbufferModelView[1].xyz);
		eastVec=normalize(gbufferModelView[0].xyz);

		gl_Position=ftransform();

		#ifdef SOFT_PARTICLES
			gl_Position.z =GetLinearDepth(gl_Position.z/gl_Position.w) * (far - near);
			gl_Position.z-=0.25;
			gl_Position.z =GetLogarithmicDepth(gl_Position.z/(far - near)) * gl_Position.w;
		#endif

		gl_Position.z -= 0.000002;
	}

#endif