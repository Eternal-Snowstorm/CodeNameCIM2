#version 330 compatibility

#define OVERWORLD
#define VSH

#include "/program/composite7.glsl"
