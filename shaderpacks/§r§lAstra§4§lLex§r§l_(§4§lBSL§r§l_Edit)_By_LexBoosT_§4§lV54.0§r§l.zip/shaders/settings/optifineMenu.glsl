/*
DEFINED for Optfine Menu
*/

#ifdef LIGHT_SHAFT
#endif
#ifdef STARS_REFLECTION
#endif
#ifdef SHOOTING_STARS_REFLECTION
#endif
#ifdef CLOUDS_REFLECTION
#endif
#ifdef SHININGSTARS_REFLECTION
#endif
#ifdef PLANET_REFLECTION
#endif
#ifdef NEBULA_REFLECTION
#endif
#ifdef GALAXY_REFLECTION
#endif
#ifdef AURORA_REFLECTION
#endif
#ifdef CLOUDS_REFLECTION
#endif
#ifdef WATER_CAUSTICS
#endif
#ifdef LENSFLARE
#endif
#ifdef SHINY_SUNRISE
#endif
#ifdef ARC_EN_CIEL
#endif
#ifdef NETHER_REFRACT
#endif
#ifdef MESA_REFRACT
#endif
#ifdef DESERT_REFRACT
#endif
#ifdef LEX_AMBIANT
#endif
#ifdef BOTW
#endif
#ifdef END_STARS
#endif
#ifdef BLOOM_JITTER
#endif
#ifdef SHOOTING_STARS_END
#endif
#ifdef BLOOM_START
#endif
#ifdef HAND_BLOOM_REDUCTION
#endif
#ifdef VANILLA_SKYBOX
#endif
#ifdef LOST_GLARE
#endif
#ifdef DOWNSCALE
#endif
#ifdef DITHERING_SCREEN_2
#endif
#ifdef WEATHER_DYNAMIC_HAND_LIGHT
#endif
#ifdef FROSTED_LENS
#endif
#ifdef FROSTED_LENS_DYNAMIC_HAND_LIGHT
#endif
#ifdef WEATHER
#endif
#ifdef NOUVELLE_PLUIE
#endif
#ifdef CORRUPTION_PLUS
#endif
#ifdef BANDES
#endif
#ifdef CONCENTRATION
#endif
#ifdef FLASH_VICTIME
#endif
#ifdef CONCENTRATION_FLASH_VICTIME
#endif
#ifdef PROJECTED_CAUSTICS
#endif
#ifdef SHADOWS_ENTITIES
#endif
#ifdef AURORA_WEATHER_PERBIOME
#endif