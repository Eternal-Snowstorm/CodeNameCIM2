#version 330 compatibility

#define OVERWORLD
#define FSH

#include "/program/gbuffers_basic.glsl"
