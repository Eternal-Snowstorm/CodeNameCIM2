#version 330 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define NETHER
#define FSH

#include "/program/composite9.glsl"
