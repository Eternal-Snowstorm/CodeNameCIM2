#version 460 compatibility

#define NETHER
#define FSH

#include "/program/gbuffers_armor_glint.glsl"
