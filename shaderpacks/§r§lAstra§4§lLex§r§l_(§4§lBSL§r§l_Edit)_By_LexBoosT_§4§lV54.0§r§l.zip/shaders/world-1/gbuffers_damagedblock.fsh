#version 460 compatibility

#define NETHER
#define FSH

#include "/program/gbuffers_damagedblock.glsl"
