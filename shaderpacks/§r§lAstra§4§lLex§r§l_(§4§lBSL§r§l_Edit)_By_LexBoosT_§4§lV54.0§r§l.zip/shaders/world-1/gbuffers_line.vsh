#version 330 compatibility

#define NETHER
#define VSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
