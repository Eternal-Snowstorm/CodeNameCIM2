#version 330 compatibility

#define NETHER
#define FSH

#include "/program/composite8.glsl"
