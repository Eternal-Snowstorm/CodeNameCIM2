#version 330 compatibility

#define NETHER
#define FSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
