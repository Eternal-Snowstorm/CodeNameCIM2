#version 330 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define GBUFFERS_HAND
#define NETHER
#define FSH

#include "/program/gbuffers_hand.glsl"
