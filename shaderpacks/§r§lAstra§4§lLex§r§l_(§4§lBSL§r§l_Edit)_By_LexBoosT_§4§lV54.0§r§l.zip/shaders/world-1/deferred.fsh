#version 330 compatibility

#define NETHER
#define FSH

#include "/program/deferred.glsl"
