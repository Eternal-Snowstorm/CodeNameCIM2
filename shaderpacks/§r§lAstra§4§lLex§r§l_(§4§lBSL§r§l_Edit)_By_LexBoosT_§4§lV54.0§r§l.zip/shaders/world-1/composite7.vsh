#version 330 compatibility

#define NETHER
#define VSH

#include "/program/composite7.glsl"
