#version 330 compatibility

#define NETHER
#define VSH

#include "/program/deferred1.glsl"
