#version 330 compatibility

#define NETHER
#define VSH

#include "/program/gbuffers_damagedblock.glsl"
