#version 460 compatibility

#define NETHER
#define FSH

#include "/program/composite10.glsl"
