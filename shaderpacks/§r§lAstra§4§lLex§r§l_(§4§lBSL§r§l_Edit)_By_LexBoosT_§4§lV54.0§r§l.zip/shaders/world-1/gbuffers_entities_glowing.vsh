#version 330 compatibility

#define GBUFFERS_ENTITIES_GLOWING
#define NETHER
#define VSH

#include "/program/gbuffers_entities.glsl"
