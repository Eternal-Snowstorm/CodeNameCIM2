#version 330 compatibility

#extension GL_ARB_shader_texture_lod : enable

#define DEFERRED
#define NETHER
#define FSH

#include "/program/deferred1.glsl"
