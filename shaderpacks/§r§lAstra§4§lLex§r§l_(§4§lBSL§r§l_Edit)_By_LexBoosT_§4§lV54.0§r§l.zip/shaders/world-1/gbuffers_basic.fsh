#version 330 compatibility

#define NETHER
#define FSH

#include "/program/gbuffers_basic.glsl"
