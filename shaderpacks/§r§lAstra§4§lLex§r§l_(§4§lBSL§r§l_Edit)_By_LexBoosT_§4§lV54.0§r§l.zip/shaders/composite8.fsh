#version 330 compatibility

#define OVERWORLD
#define FSH

#include "/program/composite8.glsl"
