#if AURORA_COLOR == 5 || COLOR_BLOC_SELECTOR == 2
    vec3 hue(float h)
    {
        h = fract(h) * 6.0;
        return clamp01(1.5 - abs(h - vec3(1.5, 3.5, 5.5))) + clamp01(vec3(0.0, 0.0, 1.0 - h));
    }
#endif

#if defined TECHNO_XP || defined MAGICAL_GLINT || COLOR_BLOC_SELECTOR == 3
    vec3 hue2(float h)
    {
        h = fract(h) * 6.0;
        return clamp01(abs(mod(h + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0);
    }
#endif