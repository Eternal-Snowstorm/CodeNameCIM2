#include "/settings/color/sculkSensorActiveColorSettings.glsl"

vec4 sculkCol=vec4(vec3(SS_R, SS_G, SS_B) / 255.0, 1.0) * SS_I;