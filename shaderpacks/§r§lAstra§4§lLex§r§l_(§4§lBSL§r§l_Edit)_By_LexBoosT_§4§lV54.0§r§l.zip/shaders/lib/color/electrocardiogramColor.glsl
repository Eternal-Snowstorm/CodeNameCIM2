#include "/settings/electroCardioColorSettings.glsl"

vec3 electroColSqrt=clamp01(vec3(EC_R, EC_G, EC_B) * EC_I / 255.0);
vec3 electroCol    =electroColSqrt * electroColSqrt;