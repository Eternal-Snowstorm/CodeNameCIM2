/*FAST MATH*/

float pow2(float x){return x*x;}

float sqrt1(float x) {
    x = 1.0 - x;
    x *= x;
    return 1.0 - x;
}

float sqrt2(float x) {
    x = 1.0 - x;
    x *= x;
    x *= x;
    return 1.0 - x;
}

float sqrt3(float x) {
    x = 1.0 - x;
    x *= x;
    x *= x;
    x *= x;
    return 1.0 - x;
}

float sqrt1inv(float x) {
    x = 1.0 - x;
    x *= x;
    return x;
}

#define clamp01(x) clamp(x, 0.0, 1.0)

#define clamp00125(x) clamp(x, 0.0, 0.125)

#define clampInv11(x) clamp(x, -1.0, 1.0)

#define clampVec2_01(x) clamp(x, vec2(0.0), vec2(1.0))

#define clampVec3_01(x) clamp(x, vec3(0.0), vec3(1.0))
#define clampVec3Inv_11(x) clamp(x, vec3(-1.0), vec3(1.0))

#define clampVec4_01(x) clamp(x, vec4(0.0) , vec4(1.0))

#define clampLmC_00933(x) clamp(x, vec2(0.0), vec2(0.9333, 1.0))