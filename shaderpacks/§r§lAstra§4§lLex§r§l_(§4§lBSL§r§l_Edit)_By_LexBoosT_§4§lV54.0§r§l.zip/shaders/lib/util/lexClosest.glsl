float lexClosest(vec2 pos)
{
	const int ditherPattern[64]=int[64](
		0,32,8,40,2,34,10,42,
		48,16,56,24,50,18,58,26,
		12,44,4,36,14,46,6,38,
		60,28,52,20,62,30,54,22,
		3,35,11,43,1,33,9,41,
		51,19,59,27,49,17,57,25,
		15,47,7,39,13,45,5,37,
		63,31,55,23,61,29,53,21
		);

	vec2 positon=floor(mod(vec2(texCoord.s*viewWidth,texCoord.t*viewHeight),8.f));
	int  dither2=ditherPattern[int(positon.x)+int(positon.y)*8];

	return float(dither2)/64.;
}

vec3 lexClosest2(vec2 pos, vec3 finalColor, float intensity) {
	int dsDither[16]=int[]( -4, 0, -3, 1, 2, -2, 3, -1, -3, 1, -4, 0, 3, -1, 2, -2 );
	int index       =(int(pos.x) & 3) * 4 + (int(pos.y) & 3);

	finalColor.xyz = clamp(finalColor.xyz * (128.0 - 1.0) + dsDither[index] * (intensity * 100), vec3(0), vec3(128.0 - 1.0));

	finalColor /= 128.0;
	return finalColor;
}