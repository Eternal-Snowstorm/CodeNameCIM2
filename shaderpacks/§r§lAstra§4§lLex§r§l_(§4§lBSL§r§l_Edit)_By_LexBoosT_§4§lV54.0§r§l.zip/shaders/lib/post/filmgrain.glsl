#ifdef FILM_GRAINS
    #if FILM_GRAINS_STYLE==1
        vec4 calcgrain(vec4 clr){

            float noiseX=clamp01(fract(sin(dot(texCoord.st * frameTimeCounter * 0.04, vec2(12.9898,78.223))) * 43758.5453));
            float noiseY=clamp01(fract(sin(dot(texCoord.st * frameTimeCounter * 0.004, vec2(12.9898,78.223) * 2.0)) * 43758.5453));
            float noiseZ=clamp01(fract(sin(dot(texCoord.st, vec2(12.9898, 78.223) * 3.0)) * 43758.5453));

            vec3 noise=vec3(noiseX, noiseY, noiseZ);

            vec3 scol=clr.rgb;

            scol+=noise * 0.005 * mix(length(scol), 1.0, 0.7) * vec3(0.2, 0.8, 1.0);
            scol*=mix(noise,vec3(1.0), 1.0 - FORCE_DU_GRAIN);
            return vec4(scol, 1.0);
        }
    #endif

    #if FILM_GRAINS_STYLE==2

        float rand(vec2 coord){
            return fract(sin(dot(coord.xy, vec2(12.9898, 78.233))) * 43758.5453);
        }

        vec3 filmgrain(vec3 color){

            const float noiseAmount=FORCE_DU_GRAIN;

            vec2 coord=texCoord.st+frameTimeCounter * 0.01;

            vec3 noise=vec3(0.0);
            noise.r=rand(coord + 0.1);
            noise.g=rand(coord);
            noise.b=rand(coord - 0.1);

            return color * (1.0 - noiseAmount + noise * noiseAmount) + noise * noiseAmount;

        }
    #endif
#endif