float lexDepth(vec2 coord) {
	return texture2D(depthtex0, coord).r;
}
vec3 fullborder(vec3 color) {

	float dtresh=1.0/(far - near) / (5000.0 * BORDER_RADIUS);
	vec4  dc    =vec4(lexDepth(texCoord.xy));
	vec3  border=vec3(1.0 / viewWidth, 1.0 / viewHeight, 0.0) * BORDER_SIZE;
	vec4  sa    =vec4(lexDepth(texCoord.xy + vec2(-border.x, - border.y)),
		 		   lexDepth(texCoord.xy + vec2(border.x, - border.y)),
		 		   lexDepth(texCoord.xy + vec2(-border.x, border.z)),
		 		   lexDepth(texCoord.xy + vec2(border.z, border.y)));


	vec4 sb = vec4(lexDepth(texCoord.xy + vec2(border.x, border.y)),
		 		   lexDepth(texCoord.xy + vec2(-border.x, border.y)),
		 		   lexDepth(texCoord.xy + vec2(border.x, border.z)),
		 		   lexDepth(texCoord.xy + vec2(border.z, - border.y)));

	vec4 dd=abs(2.0 * dc - sa - sb) - dtresh;
	     dd=step(dd.xyzw, vec4(0.0));

	float e = clamp01(dot(dd, vec4(0.25f)));
	return color * e;
}