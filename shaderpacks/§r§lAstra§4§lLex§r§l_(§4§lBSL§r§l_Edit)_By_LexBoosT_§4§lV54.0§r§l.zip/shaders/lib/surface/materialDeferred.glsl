void GetMaterials(out float smoothness, out float skyOcclusion, out vec3 normal, out vec3 fresnel3,
                  vec2 coord) {
    vec2 specularData = texture2D(colortex3, coord).rg;

    smoothness = specularData.r;
    smoothness *= smoothness;
    smoothness *= smoothness;

    smoothness = max(SMOOTHNESS_MULTIPLIER*0.01, smoothness);

    smoothness /= 2.0 - smoothness;

    skyOcclusion = specularData.g;

	normal = DecodeNormal(texture2D(colortex6, coord).xy);

	fresnel3 = texture2D(colortex1, coord).rgb * smoothness;
}