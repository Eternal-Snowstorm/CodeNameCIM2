vec3 DrawStars(inout vec3 color, vec3 starsPos){
	vec4 wpos=gbufferModelViewInverse * vec4(starsPos, 1.0);
	wpos /= wpos.w;
	vec3 lwpos = getLunarCoord(wpos.xyz);
	if( lwpos.y < 0.0) lwpos.y = -lwpos.y;
	vec3 planeCoord=lwpos / (lwpos.y + length(lwpos.xz));
	planeCoord.x += 0.399;
	planeCoord.z += 0.0;

	vec2 coord=planeCoord.xz * DISTANCE_STARS;
	coord=floor(coord * 1024.0) / 1024.0;

	float cosT=clamp01(dot(normalize(starsPos.xyz), normalize(upVec)));
	float multiplier=sqrt(sqrt(cosT)) * STARS_LIGHT_INTENSITY * (1.0 - rainStrengthShiningStars) * moonVisibility;

	#ifdef STARS_JITTER
		vec3 planeCoordNorm = normalize(planeCoord);
		float jitterBias = mix(5.0, 20.0, abs(sin(planeCoordNorm.y * 10.0) + sin(planeCoordNorm.x * 10.0) * cos(planeCoordNorm.z * 10.0)) * 0.5);
		float starJitter  =	sin(frameTimeCounter * 5.0 * STARS_JITTER_SPEED + jitterBias * 2.0) * 0.5 + 0.6;
	#else
		float starJitter = 1.0;
	#endif

	float star=1.0;
	if(cosT>0.0){
		star*=GetNoise(coord.xy);
		star*=GetNoise(coord.xy + 0.115);
		star*=GetNoise(coord.xy + 0.230);
	}

	#if STARS_COVERAGE == 1
		float starsCov = 0.8125;
	#endif

	#if STARS_COVERAGE == 2
		float starsCov = 0.7125;
	#endif

	#if STARS_COVERAGE == 3
		float starsCov = 0.6125;
	#endif

	star=clamp01(star - starsCov) * multiplier;
	star *= 1.0 - exp(- (10.0 - 9.0 * rainStrengthShiningStars) * cosT);

	#if MC_VERSION >= 11800
		star *= clamp01((cameraPosition.y + 70.0) / 8.0);
	#else
		star *= clamp01((cameraPosition.y + 6.0) / 8.0);
	#endif

	#ifdef UNDERGROUND_SKY
		if (isEyeInWater<1){
			star *= mix(clamp01((cameraPosition.y - 48.0) / 16.0), 1.0, eBS);
		}
	#endif

	color += star * pow(lightNight, vec3(0.8)) * starJitter;
	return vec3(star);
}
