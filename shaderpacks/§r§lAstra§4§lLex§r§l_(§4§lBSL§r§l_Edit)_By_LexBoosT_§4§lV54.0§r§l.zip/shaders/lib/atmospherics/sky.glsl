#ifdef OVERWORLD
vec3 GetSkyColor(vec3 viewPos, bool isReflection) {
    float timeBrightnessInv =1.0 - timeBrightness;
    float timeBrightnessInv2=timeBrightnessInv * timeBrightnessInv;
    float timeBrightnessInv4=timeBrightnessInv2 * timeBrightnessInv2;

    vec3 nViewPos=normalize(viewPos);

    float VoU=clamp(dot(nViewPos,  upVec), -1.0, 1.0);
    float VoL=clamp(dot(nViewPos, sunVec), -1.0, 1.0);

    float groundDensity=0.08 * (4.0 - 3.0 * sunVisibility) * (10.0 * pow2(rainStrengthS) + 1.0);

    float exposure       =exp2(timeBrightness * 0.75 - 0.75 + SKY_EXPOSURE_D);
    float nightExposure  =exp2(-3.5 + SKY_EXPOSURE_N);
    float weatherExposure=exp2(SKY_EXPOSURE_W);

    float gradientCurve=mix(SKY_HORIZON_F, SKY_HORIZON_N, VoL);
    float baseGradient =exp(-(1.0 - pow(1.0 - max(VoU, 0.0), gradientCurve)) /
                             (SKY_DENSITY_D + 0.025));

    #if SKY_GROUND > 0
        float groundVoU=clamp01(-VoU * 1.015 - 0.015);
        float ground   =1.0 - exp(-groundDensity * max(OVERWORLD_FOG_DENSITY, 0.125) / groundVoU);
            #if SKY_GROUND == 1
            if (!isReflection) ground = 1.0;
            #endif
    #else
        float ground = 1.0;
    #endif

    vec3 sky = skyCol * baseGradient / (SKY_I * SKY_I);

    #ifdef SKY_VANILLA
        sky = mix(sky, fogCol * baseGradient, pow(1.0 - max(VoU, 0.0), 4.0));
    #endif

    sky =sky / sqrt(sky * sky + 1.0) * exposure * sunVisibility * (SKY_I * SKY_I);
    sky*=2.0 - 0.5 * timeBrightnessInv4;
    sky*=mix(SKY_NOON, SKY_DAY, timeBrightnessInv4);

     float sunMix=(VoL * 0.5 + 0.5) * pow(clamp01(1.0 - VoU), 2.0 - sunVisibility) *
                   pow(1.0 - timeBrightness * 0.6, 3.0);
    float horizonMix=pow(1.0 - abs(VoU), 2.5) * 0.125 * (1.0 - timeBrightness * 0.5);
    float lightMix  =(1.0 - (1.0 - sunMix) * (1.0 - horizonMix));

    vec3 lightSky=pow(lightSun, vec3(4.0 - sunVisibility)) * baseGradient;
         lightSky=lightSky / (1.0 + lightSky * rainStrengthS);

    sky = mix(
        sqrt(sky * (1.0 - lightMix)),
        sqrt(lightSky),
        lightMix
    );
    sky*=sky;

    float nightGradient =exp(-max(VoU, 0.0) / SKY_DENSITY_N);
    vec3  nightSky      =lightNight * lightNight * nightGradient * nightExposure;
          nightSky     *=mix(SKY_NIGHT, 1.0, sunVisibility);
          sky           =mix(nightSky, sky, sunVisibility * sunVisibility);

    float rainGradient =exp(-max(VoU, 0.0) / SKY_DENSITY_W);
    vec3  weatherSky   =weatherCol.rgb * weatherCol.rgb * weatherExposure;
          weatherSky  *=GetLuminance(ambientCol / (weatherSky)) * (0.2 * sunVisibility + 0.2);
          sky          =mix(sky, weatherSky * rainGradient, rainStrengthS);

    sky*=ground;

    #ifdef UNDERGROUND_SKY
        if (isEyeInWater<1){
            float ug = mix(clamp01((cameraPosition.y - 48.0) / 16.0), 1.0, eBS);
            sky = mix(minLightCol * 0.125, sky, ug);
        }
    #endif

	#if MC_VERSION >= 11800
	    sky *= clamp01((cameraPosition.y + 70.0) / 8.0);
	#else
	    sky *= clamp01((cameraPosition.y + 6.0) / 8.0);
	#endif

    return sky;
}

#endif