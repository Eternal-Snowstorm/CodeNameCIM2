vec3 LostGlare(inout vec3 LostGlareColor, vec3 LostGlarePos) {
		float VoL = dot(normalize(LostGlarePos), lightVec);
		float visfactor = 0.03;
		float invvisfactor = 1.0 - visfactor;

		float visibility = clamp01(VoL * 0.5 + 0.5);
		visibility = visfactor / (1.0 - invvisfactor * visibility) - visfactor;
		visibility = clamp01(visibility * 1.015 / invvisfactor - 0.015);

		visibility = visibility * 0.055;

        vec3 glowCol = endCol2.rgb;
		glowCol = pow(glowCol * 1.0, vec3(2.3)) * LOST_GLARE_INTENSITY * 50;

        LostGlareColor += clamp01(glowCol * visibility);

		return LostGlareColor;
}
