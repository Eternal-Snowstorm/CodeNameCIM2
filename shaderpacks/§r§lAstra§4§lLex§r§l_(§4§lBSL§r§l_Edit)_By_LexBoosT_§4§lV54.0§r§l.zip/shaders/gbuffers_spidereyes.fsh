#version 460 compatibility

#define OVERWORLD
#define FSH

#include "/program/gbuffers_spidereyes.glsl"
