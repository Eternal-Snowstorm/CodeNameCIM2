#version 460 compatibility

#define OVERWORLD
#define FSH

#include "/program/deferred.glsl"
