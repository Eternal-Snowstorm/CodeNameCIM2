#version 330 compatibility

#define OVERWORLD
#define FSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"
