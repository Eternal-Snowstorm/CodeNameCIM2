#version 330 compatibility

#define OVERWORLD
#define VSH

#include "/program/shadow.glsl"
